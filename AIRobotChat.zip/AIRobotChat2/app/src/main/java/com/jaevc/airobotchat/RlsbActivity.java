package com.jaevc.airobotchat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class RlsbActivity extends AppCompatActivity {

    //调用摄像头声明
    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_CAMERA_PERMISSION = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.rlsb_activity);

        Button btn1 = (Button) findViewById(R.id.rlsbzhuc);
        Button btn2 = (Button) findViewById(R.id.rlsbbuttonback);
        Button btn3 = (Button) findViewById(R.id.rlsbsfz);

        //获取edittext输入的名字内容
        EditText editText1 = (EditText) findViewById(R.id.rlsbedittextname);
        //获取edittext输入的电话内容
        EditText editText2 = (EditText) findViewById(R.id.rlsbedittextphone);

        //人脸识别比对，通过就去预约，不通过就去注册
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //判断edittext里是否有内容，有就进行下一步，否就提示输入
                if (!isEmptyEditText(editText1) && !isEmptyEditText(editText2)) {
                    Intent intent = new Intent();
                    intent.setClass(RlsbActivity.this, GatherActivity.class);
                    startActivity(intent);
                } else {
                    // EditText 为空，给出提示
                    showToast("请在输入框中填写内容");
                }
            }
        });

        //返回上一页按钮
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(RlsbActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }


    //判断edittext里内容打印、判断函数
    private boolean isEmptyEditText(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }





    /*
           点击事件！
           判断是否拥有相机权限，如果没有就请求相机权限，如果有就使用Intent打开相机。
        */
    public void takePictureIntent(View view) {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            dispatchTakePictureIntent();
        }
    }
    /*
        使用Intent打开相机
     */
    public void  dispatchTakePictureIntent(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } catch (ActivityNotFoundException e) {
            // display error state to the user
            Log.e("WarningMsg","相机打开失败!");
        }
    }
    /*
        在拍照完成后，激活该方法，把照片数写入ImageView
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            ImageView imageView = findViewById(R.id.rlsbimageviewpaizhao);
            imageView.setImageBitmap(imageBitmap);
        }
    }
    /*
        请求认证回调函数，请求权限成功之后，再次回调打开相机
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();//打开相机
            } else {
                Toast.makeText(this, "相机权限被拒绝", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
