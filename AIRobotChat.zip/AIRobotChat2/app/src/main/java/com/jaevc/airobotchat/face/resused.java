//package com.jaevc.airobotchat.face;
//import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;
//
//import android.annotation.SuppressLint;
//import android.app.AlertDialog;
//import android.app.ProgressDialog;
//import android.content.ActivityNotFoundException;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.pm.ActivityInfo;
//import android.content.pm.PackageManager;
//import android.graphics.Bitmap;
//import android.media.AudioFormat;
//import android.media.AudioRecord;
//import android.media.MediaRecorder;
//import android.os.Bundle;
//import android.os.Environment;
//import android.os.StrictMode;
//import android.provider.MediaStore;
//import android.text.TextUtils;
//import android.util.Log;
//import android.view.View;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.activity.EdgeToEdge;
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//
//import com.iflytek.aiui.AIUIEvent;
//import com.iflytek.util.FileUtil;
//import com.iflytek.util.HttpUtil;
//import com.jaevc.airobotchat.GatherActivity;
//import com.jaevc.airobotchat.MainActivity;
//import com.jaevc.airobotchat.R;
//import com.jaevc.airobotchat.RlsbActivity;
//import com.jaevc.airobotchat.TalkActivity;
//import com.jaevc.airobotchat.exampleface.Face;
//import com.jaevc.airobotchat.util.ExceptionUtil;
//import com.jaevc.airobotchat.util.ResponseSkillConstant;
//import com.starway.starrobot.aiuiability.AIUIAbility;
//import com.starway.starrobot.aiuiability.NLPListener;
//import com.starway.starrobot.aiuiability.SpeechHelper;
//
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.net.URLEncoder;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Map;
//
//public class resused extends AppCompatActivity implements NLPListener {
//    private int resultToImageView = 0 ;// 如果是0就把照片放入R.id.sfzzp中 其他就放入R.id.rlzp
//    public static  String imagePath1="xxxxxxxxxxxxxxxx";  //请填写要比对的第一张图片路径
//    public static  String imagePath2= "xxxxxxxxxxxxxxxx"; //请填写要比对的第二张图片路径
//    private final static int MODEL_DEL = 1;
//    private File mPictureFile;
//    private int activeImageView = 1;
//    private Bitmap mImage = null;
//    private TextView TextView;
//    private ProgressDialog mProDialog;
//    private Toast mToast;
//    //    private Button ;
//    static final int REQUEST_IMAGE_CAPTURE = 1;
//    static final int REQUEST_CAMERA_PERMISSION = 100;
//
//
//    @SuppressLint("ShowToast")
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.enroll_activity);
////        findViewById(R.id.enrollbuttonpaizhaoyz).setOnClickListener(enroll.this);
////        findViewById(R.id.enrollbuttonsfbdyz).setOnClickListener(enroll.this);
//
//        // 设置屏幕为横屏
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//        //返回上一页按钮
//        Button btn1 = (Button) findViewById(R.id.enrollbuttonback);
//        //中间比对图片按钮获取，可跳转
//        TextView textView = (TextView) findViewById(R.id.enrolltextviewbidui);
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//        StrictMode.setThreadPolicy(policy);
//        //如果你用的是手机进行调试
//        AIUIAbility.getInstance().initPcmRecoderParams(MediaRecorder.AudioSource.MIC,
//                16000,
//                AudioFormat.CHANNEL_IN_MONO,
//                AudioFormat.ENCODING_PCM_16BIT,
//                AudioRecord.getMinBufferSize(16000, 2, 2));
//        /*****************************/
//        AIUIAbility.getInstance().addNLPListener(this);
//
//        AIUIAbility.getInstance().start();
//        Log.e(TAG,"AI能力成功启动！");
//        //开启休眠功能！
//        AIUIAbility.getInstance().setSleepEnable(true);
//        //语音合成初始化
//        SpeechHelper.getInstance().initSpeech(this);
//        //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
//        SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
//        Log.e(TAG,"初始化Speech完成！");
//        // 唤醒AIUI
///***********************************************************/
//
//        //返回按钮
//        btn1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent();
//                intent.setClass(resused.this, MainActivity.class);
//                startActivity(intent);
//            }
//        });
//
////        点击中间图标跳转
//        textView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                String result;
//                try {
//                    result = doCompare1(imagePath1, imagePath2);
//                } catch (Exception e) {
//                    result = "出错了！：" + e.getMessage();
//                }
////                bdjg.setText(result);
//            }
//        });
//
//
//        Button enrollbuttonsfbdyz = findViewById(R.id.enrollbuttonsfbdyz);
//        enrollbuttonpaizhaoyz.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                resultToImageView = 0;
//                takePictureIntent(v);
//            }
//        });
//
//        enrollbuttonsfbdyz.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                resultToImageView = 1;
//                takePictureIntent(v);
//            }
//        });
//
//    }
//
//    //    /*
////点击事件！
////判断是否拥有相机权限，如果没有就请求相机权限，如果有就使用Intent打开相机。
////*/
//    public  void takePictureIntent(View view) {
//        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
//        } else {
//            dispatchTakePictureIntent();
//        }
//    }
//
//    /*
//        使用Intent打开相机
//     */
//    public void  dispatchTakePictureIntent(){
//        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        try {
//            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
//        } catch (ActivityNotFoundException e) {
//            // display error state to the user
//            Log.e("WarningMsg","相机打开失败!");
//        }
//    }
//
//
//    /*
//        在拍照完成后，激活该方法，把照片数写入ImageView
//     */
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
//            Bundle extras = data.getExtras();
//            Bitmap imageBitmap = (Bitmap) extras.get("data");
//            File photoFile = null;
//            try {
//                photoFile = createImageFile();
//
//            } catch (IOException ex) {
//                // 处理文件创建错误
////                System.out.println("照片11"+photoFile);
//            }
////            if (photoFile!= null) {
////                assert imageBitmap != null;
////                imagePath1 = savePhoto(imageBitmap,photoFile);
////            }
//
//            ImageView imageView = null;
//            if(resultToImageView == 0){
//                imageView = findViewById(R.id.enrollimageviewzhaopian);
//                imagePath1 = savePhoto(imageBitmap,photoFile);
//            }else {
//                imageView = findViewById(R.id.enrollimageviewsfzzhaopian);
//                imagePath2 = savePhoto(imageBitmap,photoFile);
//            }
//            imageView.setImageBitmap(imageBitmap);
//        }
//    }
//
//    /*
//        请求认证回调函数，请求权限成功之后，再次回调打开相机
//     */
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == REQUEST_CAMERA_PERMISSION) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                dispatchTakePictureIntent();//打开相机
//            } else {
//                Toast.makeText(this, "相机权限被拒绝", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//    private File createImageFile() throws IOException {
//        // 创建一个唯一的文件名
//        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//        String imageFileName = "JPEG_" + timeStamp + "_";
//        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
//        File image = File.createTempFile(
//                imageFileName,  /* 文件名前缀 */
//                ".jpg",         /* 后缀 */
//                storageDir      /* 目录 */
//        );
//        return image;
//    }
//
//    private String savePhoto(Bitmap bitmap, File file){
//
//        try {
//            FileOutputStream fos = new FileOutputStream(file);
//            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
//            fos.close();
//            return file.getAbsolutePath();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    private String doCompare1(String imagePath1,String imagePath2) throws Exception {
//        Face demo = new Face();
//        Map<String, String> header = demo.buildHttpHeader();
//        byte[] imageByteArray1 = FileUtil.read(imagePath1);
//        String imageBase641 = new String(org.apache.commons.codec.binary.Base64.encodeBase64(imageByteArray1), "UTF-8");
//        byte[] imageByteArray2 = FileUtil.read(imagePath2);
//        String imageBase642 = new String(org.apache.commons.codec.binary.Base64.encodeBase64(imageByteArray2), "UTF-8");
//        String result = HttpUtil.doPost1(Face.WEBWFV_URL, header, "first_image=" + URLEncoder.encode(imageBase641, "UTF-8") + "&" + "second_image=" + URLEncoder.encode(imageBase642, "UTF-8"));
//        Log.e("testTag", "人脸比对接口调用结果：" + result);
////            resultTextView = findViewById(R.id.rlbdjgs);
//        try {
//            JSONObject jsonObject = new JSONObject(result);
//            String data = jsonObject.getString("data");
//            double similarity = Double.parseDouble(data);
//            // 这里的similarity就是你获取到的相似度值
//            // 你可以设置一个阈值来判断是否为同一个人
//            double threshold = 0.85;
//            if (similarity >= threshold) {
//                // 是同一个人
////                    resultTextView.setText("人脸比对的结果为:"+ similarity+",是同一个人"  );
//                // 创建AlertDialog.Builder对象
//                AlertDialog.Builder builder = new AlertDialog.Builder(this);
//                builder.setTitle("提示");
//                builder.setMessage("是同一个人，相似度为：" + similarity);
//                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        // 用户点击确定按钮后的操作，如果不需要可以留空
//                        dialog.dismiss();
//                        Intent intent = new Intent();
//                        intent.setClass(resused.this, GatherActivity.class);
//                        startActivity(intent);
//                    }
//                });
//                // 创建并显示AlertDialog
//                AlertDialog alertDialog = builder.create();
//                alertDialog.show();
//
//            } else {
//                // 不是同一个人
////                    resultTextView.setText("人脸比对的结果为:"+ similarity+",不是同一个人" );
//                AlertDialog.Builder builder = new AlertDialog.Builder(this);
//                builder.setTitle("提示");
//                builder.setMessage("不是同一个人，相似度为：" + similarity);
//                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        // 用户点击确定按钮后的操作，如果不需要可以留空
//                        dialog.dismiss();
//                        Intent intent = new Intent();
//                        intent.setClass(resused.this, RlsbActivity.class);
//                        startActivity(intent);
//                    }
//                });
//                // 创建并显示AlertDialog
//                AlertDialog alertDialog = builder.create();
//                alertDialog.show();
//
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return "人脸比对接口调用结果：" + result;
////                return "人脸比对接口调用结果：" + result;espData.getPayLoad().getFaceCompareResult() != null);
//    }
//
//    @Override
//    public void onAiuiResponse(String s) {
//        Log.i("testTag", "触发onAiuiResponse:" + s);
//        try {
//            JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
//            Log.i("testTag", "jsonObject = " + jsonObject);
//            JSONObject textObject = jsonObject.optJSONObject("text");
//            if (textObject == null) {
//                // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
//                String textValue = jsonObject.getJSONObject("nlp").getString("text");
////                Log.i("testTag","获取nlp中的 text 对象= "+textValue);
//
//                textObject = new JSONObject(ExceptionUtil.handleText(textValue));
//                Log.i("testTag", "处理后的 text 对象textObject= " + ExceptionUtil.handleText(textValue));
//            }
////            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
//            JSONObject intentObject = textObject.optJSONObject("intent");
//
//            Log.i("testTag", "获取jsonObject中的 intent 对象= " + intentObject);
//
//            if (intentObject.length() == 0 || TextUtils.equals(intentObject.getString("rc"), "4")) {// 无效问答：无效语义结果，不做回复。
//                return;
//            }
//            //语音识别的文字
//            if (intentObject.has("text")) {
//                String text = intentObject.getString("text");
//                Log.i(TAG, "onAiuiResponse text: " + text);
//                TextView MyspeakView = (TextView) findViewById(R.id.talktextviewtiwen);
//                MyspeakView.setText(text);
//            }
//
//
//            if (intentObject.has("answer")) {
//
//                // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);
//
//                JSONObject answerObject = intentObject.optJSONObject("answer");
//                String answerText = answerObject.getString("text");
//
//                //界面显示回答
//
//                Log.e(TAG, "answerText = " + answerText);
//                TextView answer =(TextView) findViewById(R.id.talktextviewanswer);
//                answer.setText(answerText);
//                //语音回答
//                //SpeechHelper.getInstance().speak(answerText);
//            }
//
//            Log.e(TAG, " service =  " + String.valueOf(intentObject.has("service")) + "  " + intentObject.getString("service") + "   " + ResponseSkillConstant.CONTROL_VOICE);
//            Log.e(TAG, " 比对 结果 " + String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
//
//            Log.e(TAG, String.valueOf(textObject.has("service") &&
//                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
//            if (intentObject.has("service") &&
//                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
//                //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配
//
//                JSONArray semanticArray = intentObject.optJSONArray("semantic");
//                JSONObject semanticObject = (JSONObject) semanticArray.get(0);
//
//                String intent = semanticObject.getString("intent");
//                Log.e(TAG, " 命令意图 intent = " + intent);
//                switch (intent) {
//                    case "sleep":// AIUI休眠命令
//                        AIUIAbility.getInstance().sleep();
//                        break;
//                    case "app_service"://  去访客登记页面
//                        Intent intentActivity = new Intent();
//                        intentActivity.setClass(resused.this, resused.class);
//                        startActivity(intentActivity);
//                        break;
//                    case "question_service":
//                        Intent intentActivity_question = new Intent();
//                        intentActivity_question.setClass(resused.this, TalkActivity.class);
//                        startActivity(intentActivity_question);
//                    case "continue"://播放继续，要与技能中的意图名称匹配
//                        Log.e(TAG, "Case");
//                        break;
//                }
//            }
//        }catch (Exception e){
//            ExceptionUtil.printStackTrace("testTag",e);
////           e.printStackTrace();
//        }
//
//    }
//
//    @Override
//    public void onAiuiWakeUp() {
//        SpeechHelper.getInstance().speak("请将摄像头对准人脸，身份证放置感应处，进行人脸比对");
//    }
//
//    @Override
//    public void onAiuiSleep() {
//
//    }
//
//    @Override
//    public void onAiuiEvent(AIUIEvent var1) {
//
//    }
//
//    @Override
//    public void onError(int var1) {
//
//    }
//}
