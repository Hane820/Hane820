package com.jaevc.airobotchat.util;

import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.iflytek.aiui.AIUIEvent;
import com.starway.starrobot.aiuiability.AIUIAbility;

import org.json.JSONObject;

public class AIUIResponseUtil {

    private static final String TAG = "AIUIResponseUtil";
    private String mAiuiSubType = "nlp";

}
