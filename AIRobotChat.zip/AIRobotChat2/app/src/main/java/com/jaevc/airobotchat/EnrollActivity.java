package com.jaevc.airobotchat;

import static com.jaevc.airobotchat.MyApp.WEBAPI_API_KEY;
import static com.jaevc.airobotchat.MyApp.WEBAPI_APPID;
import static com.jaevc.airobotchat.MyApp.WEBWFV_URL;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.hardware.idscanner.IDCardInfo;
import com.starway.starrobot.commonability.HardwareServer;
import com.starway.starrobot.commonability.hardware.base.BaseHardware;
import com.starway.starrobot.face.FaceAlignmentHelper;
import com.starway.starrobot.face.FileUtil;


public class EnrollActivity extends AppCompatActivity  {
    private static final String TAG = MainActivity.class.getSimpleName();
    static final int REQUEST_IMAGE_CAPTURE = 1;
    private HandlerThread handlerThread;
    private Handler mHandler;

    // 拍照得到的照片文件
    private Bitmap mImage = null;

    //身份证阅读器获取的图片
    private Bitmap headImg;

    private TextView name, idcardNumber, birthday;
    private ImageView idCardImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enroll_activity);
        handlerThread = new HandlerThread("faceThead");
        handlerThread.start();
        mHandler = new Handler(handlerThread.getLooper());
        Button take_pic= findViewById(R.id.take_pic);
        take_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mIntent =new Intent(EnrollActivity.this,CameraActivity.class);
               startActivityForResult(mIntent, 1000);
            }
        });

        Button online_register= findViewById(R.id.online_register);
        online_register.setOnClickListener(new View.OnClickListener() {
            //刷身份证获取信息显示
            @Override
            public void onClick(View v) {
                initIdScannerListener();
            }
        });

        View online_verify= findViewById(R.id.online_verify);
        online_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //用拍照的图片和身份证阅读器获取的图片进行比对
                faceAligement(mImage, headImg);
                //    faceAligement(mImage, mImage);
            }
        });

        initView();
    }

    /**
     * 初始化控件
     */
    private void initView() {
        name = findViewById(R.id.name);
        idcardNumber = findViewById(R.id.id_card_number);
        birthday = findViewById(R.id.birthday);
        idCardImage = findViewById(R.id.head_img);

        //界面按钮点击处理
//        findViewById(R.id.online_register).setOnClickListener(this);
//        findViewById(R.id.take_pic).setOnClickListener(this);
//        findViewById(R.id.online_verify).setOnClickListener(this);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }
        String fileSrc = null;
        if (requestCode == 1000) {
            fileSrc = data.getStringExtra("bitmap");
            if (null != fileSrc) {
                mImage = BitmapFactory.decodeFile(fileSrc);
                ((ImageView) findViewById(R.id.online_img)).setImageBitmap(mImage);
            }
        }

    }

    /**
     * 监听身份证扫描仪
     */
    private void initIdScannerListener() {
        HardwareServer.getInstance().startIdScanWithListener(new BaseHardware.idScanCallback() {
            @Override
            public void onIDscanEnd(final IDCardInfo idCardInfo, final byte[] bytes) {
                Log.d(TAG, "result = " + idCardInfo.getName() + " " + idCardInfo.getIdcardno());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        name.setText("姓名： " + idCardInfo.getName());
                        idcardNumber.setText("身份证号： **************");
                        birthday.setText("出生日期： ******************");
                        headImg = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        idCardImage.setImageBitmap(headImg);
                        HardwareServer.getInstance().stopIdScanner();
                    }
                });
            }

            @Override
            public void onIDscanFailed(int i, String s) {
                Log.e("idscan error", s);
            }
        });
    }

    /**
     * 人脸比对webApi 1:1比对
     */
    private void faceAligement(final Bitmap firstBitmap, final Bitmap secordBitmap) {
        if (null == firstBitmap || null == secordBitmap) {
            showToast("图片数据不能为空");
            return;
        }
        FaceAlignmentHelper.getInstance().init(WEBAPI_APPID, WEBAPI_API_KEY);
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                boolean result = FaceAlignmentHelper.getInstance().faceAlignment(WEBWFV_URL,
                        FileUtil.Bitmap2Bytes(firstBitmap), FileUtil.Bitmap2Bytes(secordBitmap));
                if (result) {
                    showToast("人脸比对通过");
                } else {
                    showToast("人脸比对不通过");
                }
            }
        });
    }


    /**
     * 显示toast提升信息
     *
     * @param value
     */
    private void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }

}
