package com.jaevc.airobotchat;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.iflytek.aiui.AIUIEvent;

import com.jaevc.airobotchat.util.ExceptionUtil;
import com.jaevc.airobotchat.util.ResponseSkillConstant;
import com.starway.starrobot.aiuiability.AIUIAbility;
import com.starway.starrobot.aiuiability.NLPListener;
import com.starway.starrobot.aiuiability.SpeechHelper;

import org.json.JSONArray;
import org.json.JSONObject;

public class CopyActivity extends AppCompatActivity implements NLPListener
{



    //多个textview声明，获取上一页传来的信息，写入
    private TextView textView1;
    private TextView textView2;
    private TextView textView3;
    private TextView textView4;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.copy_activity);

        //获取文字，写入姓名框里
        textView1 = findViewById(R.id.textViewNewPage1);
        //获取文字，写入电话号码
        textView2 = findViewById(R.id.textViewNewPage2);
        //获取文字，写入身份证号码
        textView3 = findViewById(R.id.textViewNewPage3);
        //获取文字，写入预约项目
        textView4 = findViewById(R.id.textViewNewPage4);
        //返回上一页按钮
        Button btn = (Button) findViewById(R.id.copybuttonback);
        //打印按钮，点击打印出纸质票
        Button btn1 = (Button) findViewById(R.id.copybuttondayin);



        //如果你用的是手机进行调试
        AIUIAbility.getInstance().initPcmRecoderParams(MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                AudioRecord.getMinBufferSize(16000, 2, 2));
        /*****************************/
        AIUIAbility.getInstance().addNLPListener(this);

        AIUIAbility.getInstance().start();
        Log.e(TAG,"AI能力成功启动！");
        //开启休眠功能！
        AIUIAbility.getInstance().setSleepEnable(true);
        //语音合成初始化
        SpeechHelper.getInstance().initSpeech(this);
        //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
        SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
        Log.e(TAG,"初始化Speech完成！");
        // 唤醒AIUI
/***********************************************************/




        //上一页跳转按钮
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(CopyActivity.this, GatherActivity.class);
                startActivity(intent);
            }
        });


        //判断信息是否有，并打印在页面中
        if (getIntent().hasExtra("text1") && getIntent().hasExtra("text2") && getIntent().hasExtra("text3") && getIntent().hasExtra("text4")) {
            String text1 = getIntent().getStringExtra("text1");
            String text2 = getIntent().getStringExtra("text2");
            String text3 = getIntent().getStringExtra("text3");
            String text4 = getIntent().getStringExtra("text4");
            textView1.setText("姓名：" +text1);
            textView2.setText("电话号码：" +text2);
            textView3.setText("身份证号码：" +text3);
            textView4.setText("预约项目：" +text4);
        }

    }


    @Override
    public void onAiuiResponse(String s) {
        Log.i("testTag", "触发onAiuiResponse:" + s);
        try {
            JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
            Log.i("testTag", "jsonObject = " + jsonObject);
            JSONObject textObject = jsonObject.optJSONObject("text");
            if (textObject == null) {
                // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
                String textValue = jsonObject.getJSONObject("nlp").getString("text");
//                Log.i("testTag","获取nlp中的 text 对象= "+textValue);

                textObject = new JSONObject(ExceptionUtil.handleText(textValue));
                Log.i("testTag", "处理后的 text 对象textObject= " + ExceptionUtil.handleText(textValue));
            }
//            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
            JSONObject intentObject = textObject.optJSONObject("intent");

            Log.i("testTag", "获取jsonObject中的 intent 对象= " + intentObject);

            if (intentObject.length() == 0 || TextUtils.equals(intentObject.getString("rc"), "4")) {// 无效问答：无效语义结果，不做回复。
                return;
            }
            //语音识别的文字
            if (intentObject.has("text")) {
                String text = intentObject.getString("text");
                Log.i(TAG, "onAiuiResponse text: " + text);
                TextView MyspeakView = (TextView) findViewById(R.id.talktextviewtiwen);
                MyspeakView.setText(text);
            }


            if (intentObject.has("answer")) {

                // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);

                JSONObject answerObject = intentObject.optJSONObject("answer");
                String answerText = answerObject.getString("text");

                //界面显示回答

                Log.e(TAG, "answerText = " + answerText);
                TextView answer =(TextView) findViewById(R.id.talktextviewanswer);
                answer.setText(answerText);
                //语音回答
                //SpeechHelper.getInstance().speak(answerText);
            }

            Log.e(TAG, " service =  " + String.valueOf(intentObject.has("service")) + "  " + intentObject.getString("service") + "   " + ResponseSkillConstant.CONTROL_VOICE);
            Log.e(TAG, " 比对 结果 " + String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));

            Log.e(TAG, String.valueOf(textObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
            if (intentObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
                //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配

                JSONArray semanticArray = intentObject.optJSONArray("semantic");
                JSONObject semanticObject = (JSONObject) semanticArray.get(0);

                String intent = semanticObject.getString("intent");
                Log.e(TAG, " 命令意图 intent = " + intent);
                switch (intent) {
                    case "sleep":// AIUI休眠命令
                        AIUIAbility.getInstance().sleep();
                        break;
                    case "app_service"://  去访客登记页面
                        Intent intentActivity = new Intent();
                        intentActivity.setClass(CopyActivity.this, EnrollActivity.class);
                        startActivity(intentActivity);
                        break;
                    case "question_service":
                        Intent intentActivity_question = new Intent();
                        intentActivity_question.setClass(CopyActivity.this, TalkActivity.class);
                        startActivity(intentActivity_question);
                    case "continue"://播放继续，要与技能中的意图名称匹配
                        Log.e(TAG, "Case");
                        break;
                }
            }
        }catch (Exception e){
            ExceptionUtil.printStackTrace("testTag",e);
//           e.printStackTrace();
        }


    }

    @Override
    public void onAiuiWakeUp() {
        SpeechHelper.getInstance().speak("感谢您耐心填写信息，点击按钮打印出凭条吧");

    }

    @Override
    public void onAiuiSleep() {

    }

    @Override
    public void onAiuiEvent(AIUIEvent var1) {

    }

    @Override
    public void onError(int var1) {

    }
}
