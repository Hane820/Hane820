package com.jaevc.airobotchat;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.iflytek.aiui.AIUIEvent;

import com.jaevc.airobotchat.util.ExceptionUtil;
import com.jaevc.airobotchat.util.ResponseSkillConstant;
import com.starway.starrobot.aiuiability.AIUIAbility;
import com.starway.starrobot.aiuiability.NLPListener;
import com.starway.starrobot.aiuiability.SpeechHelper;

import org.json.JSONArray;
import org.json.JSONObject;

public class SchoolserveActivity extends AppCompatActivity {

    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.schoolserve_activity);

        //返回上一页按钮
        Button btn = (Button) findViewById(R.id.schoolservebuttonback);


        //返回上一页跳转
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(SchoolserveActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        /*************************************************************/
        AIUIAbility.getInstance().addNLPListener((NLPListener) SchoolserveActivity.this);



        AIUIAbility.getInstance().start();
        Log.e(TAG,"AI能力成功启动！");
        //开启休眠功能！
        AIUIAbility.getInstance().setSleepEnable(true);
        //语音合成初始化
        SpeechHelper.getInstance().initSpeech(this);
        //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
        SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
        Log.e(TAG,"初始化Speech完成！");
        // 唤醒AIUI

        onAiuiWakeUp();

    }

    /****************通用***********************/

    public void onAiuiResponse(String s) {
        Log.i("testTag", "触发onAiuiResponse:" + s);
        try {
            JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
            Log.i("testTag","jsonObject = "+jsonObject);
            JSONObject textObject = jsonObject.optJSONObject("text");
            if(textObject == null){
                // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
                String textValue = jsonObject.getJSONObject("nlp").getString("text");
//                Log.i("testTag","获取nlp中的 text 对象= "+textValue);

                textObject = new JSONObject(ExceptionUtil.handleText(textValue));
                Log.i("testTag","处理后的 text 对象textObject= "+ExceptionUtil.handleText(textValue));
            }
//            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
            JSONObject intentObject = textObject.optJSONObject("intent");

            Log.i("testTag","获取jsonObject中的 intent 对象= "+intentObject);

            if(intentObject.length()==0 || TextUtils.equals(intentObject.getString("rc"),"4")){// 无效问答：无效语义结果，不做回复。
                return;
            }
            //语音识别的文字
            if (intentObject.has("text")) {
                String text = intentObject.getString("text");
                Log.i(TAG, "onAiuiResponse text: " + text);
            }



            if (intentObject.has("answer")) {

                // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);

                JSONObject answerObject = intentObject.optJSONObject("answer");
                String answerText = answerObject.getString("text");

                //界面显示回答
                // TextView answerView = (TextView) findViewById(R.id.txtArea);
                //   answerView.setText(answerText);
                Log.e(TAG,"answerText = " + answerText);
                //语音回答
//                SpeechHelper.getInstance().speak(answerText);
            }

            Log.e(TAG," service =  "+String.valueOf(intentObject.has("service"))+"  "+intentObject.getString("service")+"   "+ ResponseSkillConstant.CONTROL_VOICE);
            Log.e(TAG," 比对 结果 "+String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));

            Log.e(TAG, String.valueOf(textObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
            if (intentObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
                //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配

                JSONArray semanticArray = intentObject.optJSONArray("semantic");
                JSONObject semanticObject = (JSONObject) semanticArray.get(0);

                String intent = semanticObject.getString("intent");
                Log.e(TAG," 命令意图 intent = "+intent);
                switch (intent) {
                    case "sleep":// AIUI休眠命令
                        AIUIAbility.getInstance().sleep();
                        break;
                    case "app_service"://  去访客登记页面
                        Intent intentActivity = new Intent();
                        intentActivity.setClass(SchoolserveActivity.this, EnrollActivity.class);
                        startActivity(intentActivity);
                        break;
                    case "voice_activation"://语音唤醒去主界面
                        Intent intentActivity_voice = new Intent();
                        intentActivity_voice.setClass(SchoolserveActivity.this, MainActivity.class);
                        startActivity(intentActivity_voice);
                        break;
                    case "continue"://播放继续，要与技能中的意图名称匹配
                        Log.e(TAG,"Case");
                        break;
                }
            }

        } catch (Exception e) {
            ExceptionUtil.printStackTrace("testTag",e);
//           e.printStackTrace();
        }

    }


    public void onAiuiWakeUp() {
        SpeechHelper.getInstance().speak("你好，我是小途，有什么事尽管吩咐！");
    }

    /**
     * AIUI休眠
     */

    public void onAiuiSleep() {
        SpeechHelper.getInstance().speak("好，有什么事随时呼唤我！");
    }


    public void onAiuiEvent(AIUIEvent var1) {

        Log.e(TAG,"触发AIUIEvent事件！");

    }


    public void onError(int var1) {
        SpeechHelper.getInstance().speak("我好像哪里有点问题！，给我一点时间，我会自己调整好的。");
    }


    protected void onPause() {
        super.onPause();
        AIUIAbility.getInstance().stop();
    }
}

