package com.jaevc.airobotchat;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.iflytek.aiui.AIUIEvent;
import com.jaevc.airobotchat.util.ExceptionUtil;
import com.jaevc.airobotchat.util.ResponseSkillConstant;
import com.starway.starrobot.aiuiability.AIUIAbility;
import com.starway.starrobot.aiuiability.NLPListener;
import com.starway.starrobot.aiuiability.SpeechHelper;

import org.json.JSONArray;
import org.json.JSONObject;

public class TalkActivity extends AppCompatActivity implements NLPListener {

    private EditText editText;
    private TextView textView;

    /*语音输入的常量声明*/
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 1;
    private static final int REQUEST_VOICE_INPUT = 2;
    private Button button;
    private static final int PERMISSION_REQUEST_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.talk_activity);

        //如果你用的是手机进行调试
        AIUIAbility.getInstance().initPcmRecoderParams(MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                AudioRecord.getMinBufferSize(16000, 2, 2));
        /*****************************/
        AIUIAbility.getInstance().addNLPListener(this);

        AIUIAbility.getInstance().start();
        Log.e(TAG,"AI能力成功启动！");
        //开启休眠功能！
        AIUIAbility.getInstance().setSleepEnable(true);
        //语音合成初始化
        SpeechHelper.getInstance().initSpeech(this);
        //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
        SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
        Log.e(TAG,"初始化Speech完成！");
        // 唤醒AIUI
/***********************************************************/

        //返回上一页按钮
        Button btn = (Button) findViewById(R.id.talkbuttonback);
        //长按或者点击后语音输入问题
        Button btn1 = (Button) findViewById(R.id.talkbuttonyuyin);
        //发送信息按钮
        Button btn2 = (Button) findViewById(R.id.talkbuttonfasong);
        //获取回答框位置id，当识别完输入的问题后，给出回答并语音播报
        TextView textView1 = (TextView) findViewById(R.id.talktextviewanswer);
        //获取video布局id位置
        VideoView videoView = findViewById(R.id.videoView);


        // 设置视频路径，这里假设视频文件在raw目录下，命名为video_example
        String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.video;
        //传入路径
        videoView.setVideoURI(Uri.parse(videoPath));
        //自动播放视频
        videoView.start();
        //循环播放视频

        //唤醒
        onAiuiWakeUp();

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setLooping(true);
                videoView.start();
            }
        });




        //返回上一页点击跳转
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(TalkActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        //语音按钮点击事件
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendNotification ();

            }

            private void sendNotification() {
                AlertDialog.Builder builder = new AlertDialog.Builder(TalkActivity.this);
                builder.setIcon(R.drawable.huatong);
                builder.setTitle("语音输入");
                builder.setMessage("可以选择开始，说完后点击结束");
                builder.setPositiveButton("开始", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 点击确定按钮后的操作
                    }
                });
                builder.setNegativeButton("结束", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //点击结束后按钮操作
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 点击取消按钮后的操作
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });


        //获取输入和提问框
        editText = findViewById(R.id.talkedittextshuru);
        textView = findViewById(R.id.talktextviewtiwen);

        // 设置按钮点击事件，将 EditText 的内容显示到 TextView 中
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = editText.getText().toString();
                textView.setText(text);
            }
        });


        }

    @Override
    public void onAiuiResponse(String s) {
        Log.i("testTag", "触发onAiuiResponse:" + s);
        try {
            JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
            Log.i("testTag", "jsonObject = " + jsonObject);
            JSONObject textObject = jsonObject.optJSONObject("text");
            if (textObject == null) {
                // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
                String textValue = jsonObject.getJSONObject("nlp").getString("text");

//                /**********************************/
//                JSONObject intentObject = textObject.optJSONObject("text");
//                String text = intentObject.getString("text");
//                Log.i("testTag","获取nlp中的 text 对象= "+text);
//                TextView MyspeakView = (TextView) findViewById(R.id.talktextviewtiwen);
//                MyspeakView.setText(text);
//                /***********加上以上之后所有语句都会被识别而不是仅限问答*******************/

                textObject = new JSONObject(ExceptionUtil.handleText(textValue));
                Log.i("testTag", "处理后的 text 对象textObject= " + ExceptionUtil.handleText(textValue));
            }
//            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
            JSONObject intentObject = textObject.optJSONObject("intent");

            Log.i("testTag", "获取jsonObject中的 intent 对象= " + intentObject);

            if (intentObject.length() == 0 || TextUtils.equals(intentObject.getString("rc"), "4")) {// 无效问答：无效语义结果，不做回复。
                return;
            }
            //语音识别的文字
            if (intentObject.has("text")) {
                String text = intentObject.getString("text");
                Log.i(TAG, "onAiuiResponse text: " + text);
                TextView MyspeakView = (TextView) findViewById(R.id.talktextviewtiwen);
                MyspeakView.setText(text);
            }


            if (intentObject.has("answer")) {

                // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);

                JSONObject answerObject = intentObject.optJSONObject("answer");
                String answerText = answerObject.getString("text");

                //界面显示回答

                Log.e(TAG, "answerText = " + answerText);
                TextView answer =(TextView) findViewById(R.id.talktextviewanswer);
                answer.setText(answerText);
                //语音回答
                //SpeechHelper.getInstance().speak(answerText);
            }

            Log.e(TAG, " service =  " + String.valueOf(intentObject.has("service")) + "  " + intentObject.getString("service") + "   " + ResponseSkillConstant.CONTROL_VOICE);
            Log.e(TAG, " 比对 结果 " + String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));

            Log.e(TAG, String.valueOf(textObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
            if (intentObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
                //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配

                JSONArray semanticArray = intentObject.optJSONArray("semantic");
                JSONObject semanticObject = (JSONObject) semanticArray.get(0);

                String intent = semanticObject.getString("intent");
                Log.e(TAG, " 命令意图 intent = " + intent);
                switch (intent) {
                    case "sleep":// AIUI休眠命令
                        AIUIAbility.getInstance().sleep();
                        break;
                    case "app_service"://  去访客登记页面
                        Intent intentActivity = new Intent();
                        intentActivity.setClass(TalkActivity.this, EnrollActivity.class);
                        startActivity(intentActivity);
                        break;
                    case "question_service":
                        Intent intentActivity_question = new Intent();
                        intentActivity_question.setClass(TalkActivity.this, TalkActivity.class);
                        startActivity(intentActivity_question);
                    case "continue"://播放继续，要与技能中的意图名称匹配
                        Log.e(TAG, "Case");
                        break;
                }
            }
        }catch (Exception e){
            ExceptionUtil.printStackTrace("testTag",e);
//           e.printStackTrace();
        }
    }

    @Override
    public void onAiuiWakeUp() {
        SpeechHelper.getInstance().speak("有什么问题尽管问：你可以问我：请问某某地方在哪里，或是我要找某某老师");

    }

    @Override
    public void onAiuiSleep() {
        SpeechHelper.getInstance().speak("没什么事小途就走了哦，期待我们下次见面");

        Intent intentActivity = new Intent();
        intentActivity.setClass(TalkActivity.this, homepagejava.class);
        startActivity(intentActivity);
    }

    @Override
    public void onAiuiEvent(AIUIEvent var1) {


    }

    @Override
    public void onError(int var1) {

    }
}

