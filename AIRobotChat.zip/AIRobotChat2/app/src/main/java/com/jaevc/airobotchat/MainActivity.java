package com.jaevc.airobotchat;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.iflytek.aiui.AIUIConstant;
import com.iflytek.aiui.AIUIEvent;

import com.jaevc.airobotchat.util.ExceptionUtil;
import com.jaevc.airobotchat.util.ResponseSkillConstant;
import com.starway.starrobot.aiuiability.AIUIAbility;
import com.starway.starrobot.aiuiability.NLPListener;
import com.starway.starrobot.aiuiability.SpeechHelper;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements NLPListener{


        private Button button;
        private CameraManager cameraManager;
        private RelativeLayout relativeLayout;
        private TextView textView;

        /*摄像头调用常量声明*/
        private static final String TAG = "MainActivity";
        static final int REQUEST_IMAGE_CAPTURE = 1;
        static final int REQUEST_CAMERA_PERMISSION = 100;

        private int mAIUIState = AIUIConstant.STATE_IDLE;

        /*语音输入的常量声明*/
        private static final int REQUEST_RECORD_AUDIO_PERMISSION = 1;
        private static final int REQUEST_VOICE_INPUT = 2;
        private static final int PERMISSION_REQUEST_CODE = 1;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_main);


            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                Log.e("testTag","用户没有读取权限，现在申请！");
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
            }
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                Log.e("testTag","用户没有写入权限，现在申请！");
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
            }


            Log.e("testTag","权限检查完毕！"+ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)+ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE));
            // 设置屏幕为横屏
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

            //问题咨询按钮
            Button btn1 = (Button) findViewById(R.id.buttonwtzx);
            //访客登记按钮
            Button btn2 = (Button) findViewById(R.id.buttonfkdj);
            //校园服务按钮
            Button btn3 = (Button) findViewById(R.id.buttonxyfw);

            //主页面访客登记标题
            TextView textView1 = findViewById(R.id.textviewtitlefkdj);

            //实现标题淡入效果
            ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(textView1, "alpha", 0f, 1f);
            alphaAnimator.setDuration(1000);
            alphaAnimator.start();

            //跑马灯效果
            //TextView marqueeTextView = findViewById(R.id.);
           // marqueeTextView.setSelected(true);

            //问题咨询的按钮跳转
            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this, TalkActivity.class);
                    startActivity(intent);
                }
            });
            //访客登记的按钮跳转
            btn2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this, EnrollActivity.class);
                    startActivity(intent);
                }
            });

            //校园服务的按钮跳转
            btn3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this, SchoolserveActivity.class);
                    startActivity(intent);
                }
            });

            AIUIAbility.getInstance().initAIUIAbility(this);


            /*****************************/
            //如果你用的是手机进行调试
            AIUIAbility.getInstance().initPcmRecoderParams(MediaRecorder.AudioSource.MIC,
                    16000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    AudioRecord.getMinBufferSize(16000, 2, 2));
            /*****************************/


            AIUIAbility.getInstance().addNLPListener(this);



            AIUIAbility.getInstance().start();
            Log.e(TAG,"AI能力成功启动！");
            //开启休眠功能！
            AIUIAbility.getInstance().setSleepEnable(true);
            //语音合成初始化
            SpeechHelper.getInstance().initSpeech(this);
            //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
            SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
            Log.e(TAG,"初始化Speech完成！");
            // 唤醒AIUI

            onAiuiWakeUp();

            //startWakeUpAction();

        }


    @Override
        public void onAiuiResponse(String s) {
        Log.i("testTag", "触发onAiuiResponse:" + s);
        try {
            JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
            Log.i("testTag","jsonObject = "+jsonObject);
            JSONObject textObject = jsonObject.optJSONObject("text");
            if(textObject == null){
                // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
                String textValue = jsonObject.getJSONObject("nlp").getString("text");
//                Log.i("testTag","获取nlp中的 text 对象= "+textValue);

                textObject = new JSONObject(ExceptionUtil.handleText(textValue));
                Log.i("testTag","处理后的 text 对象textObject= "+ExceptionUtil.handleText(textValue));
            }
//            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
            JSONObject intentObject = textObject.optJSONObject("intent");

            Log.i("testTag","获取jsonObject中的 intent 对象= "+intentObject);

            if(intentObject.length()==0 || TextUtils.equals(intentObject.getString("rc"),"4")){// 无效问答：无效语义结果，不做回复。
                return;
            }
            //语音识别的文字
            if (intentObject.has("text")) {
                String text = intentObject.getString("text");
                Log.i(TAG, "onAiuiResponse text: " + text);
            }



            if (intentObject.has("answer")) {

               // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);

                JSONObject answerObject = intentObject.optJSONObject("answer");
                String answerText = answerObject.getString("text");

                //界面显示回答
               // TextView answerView = (TextView) findViewById(R.id.txtArea);
             //   answerView.setText(answerText);
                Log.e(TAG,"answerText = " + answerText);
                //语音回答
//                SpeechHelper.getInstance().speak(answerText);
            }

            Log.e(TAG," service =  "+String.valueOf(intentObject.has("service"))+"  "+intentObject.getString("service")+"   "+ResponseSkillConstant.CONTROL_VOICE);
            Log.e(TAG," 比对 结果 "+String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));

            Log.e(TAG, String.valueOf(textObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
            if (intentObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
                //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配

                JSONArray semanticArray = intentObject.optJSONArray("semantic");
                JSONObject semanticObject = (JSONObject) semanticArray.get(0);

                String intent = semanticObject.getString("intent");
                Log.e(TAG," 命令意图 intent = "+intent);
                switch (intent) {
                    case "sleep":// AIUI休眠命令
                        AIUIAbility.getInstance().sleep();
                        break;
                    case "app_service"://  去访客登记页面
                        Intent intentActivity = new Intent();
                        intentActivity.setClass(MainActivity.this, EnrollActivity.class);
                        startActivity(intentActivity);
                        break;
                    case "question_service":
                        Intent intentActivity_question = new Intent();
                        intentActivity_question.setClass(MainActivity.this, TalkActivity.class);
                        startActivity(intentActivity_question);
                    case "continue"://播放继续，要与技能中的意图名称匹配
                        Log.e(TAG,"Case");
                        break;
                }
            }

        } catch (Exception e) {
            ExceptionUtil.printStackTrace("testTag",e);
//           e.printStackTrace();
        }

    }

    /**
     * AIUI被唤醒的回调函数
     */
    @Override
    public void onAiuiWakeUp() {
        SpeechHelper.getInstance().speak("你好，我是小途，有什么事尽管吩咐！");
    }

    /**
     * AIUI休眠
     */
    @Override
    public void onAiuiSleep() {
        SpeechHelper.getInstance().speak("好，有什么事随时呼唤我！");
    }

    @Override
    public void onAiuiEvent(AIUIEvent var1) {

            Log.e(TAG,"触发AIUIEvent事件！");

    }

    @Override
    public void onError(int var1) {
        SpeechHelper.getInstance().speak("我好像哪里有点问题！，给我一点时间，我会自己调整好的。");
    }

    @Override
    protected void onPause() {
        super.onPause();
        AIUIAbility.getInstance().stop();
    }
//    /**戴静****************************************************/
//    public WakeUpActionHelper mWakeUpActionHelper;
//
//    private Handler mHandler;
//
//
//    public void startWakeUpAction() {
//        Log.d(TAG, "startWakeUpAction");
//        if (null != mWakeUpActionHelper) {
//            Log.d(TAG, "startWakeUpAction return");
//            SpeechHelper.getInstance().speak("你好，请问有什么可以帮您");
//            SpeechHelper.getInstance().speak("你好，我是小途，被您唤醒啦");
//
//            Log.e(TAG,"wakeupaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
//            return;
//        }
//        mWakeUpActionHelper = new WakeUpActionHelper(MainActivity.this);
//        mWakeUpActionHelper.setOnWakeUpActionListener(new WakeUpActionHelper.OnWakeUpActionListener() {
//            @Override
//            public boolean getAngle(int angle) {
//                //唤醒角度
//                Log.d(TAG, "angle = " + angle);
//                //防止语音唤醒后，多次唤醒
//                //stopVoiceWakeup();
//                AIUIAbility.getInstance().start();
//                SpeechHelper.getInstance().initSpeech(MainActivity.this);
//                SpeechHelper.getInstance().speak("你好，请问有什么可以帮您");
//                mHandler.postDelayed(() -> {
//                    //设置5s后停止aiui语音交互，重新开启唤醒监听
//                    AIUIAbility.getInstance().stop();
//                    startWakeUpAction();
//                   // print("进入休眠模式，可以通过语音唤醒：小途小途");
//                }, 5000);
//                return false;
//            }
//
//
//            public void stopVoiceWakeup() {
//                Log.d(TAG, "stopVoiceWakeup");
//                try {
//                    if (null != mWakeUpActionHelper) {
//                        mWakeUpActionHelper.unregisterWakeUpActionReceiver();
//                        mWakeUpActionHelper = null;
//                    }
//                } catch (Exception ex) {
//                    Log.d(TAG, "ex " + ex.getLocalizedMessage());
//                    ex.printStackTrace();
//                }
//            }
//
//            @Override
//            public void onRotateEnd(int angle) {
//
//            }
//
//            @Override
//            public void onForwardEnd() {
//            }
//        });
//        mWakeUpActionHelper.registerWakeUpActionReceiver();
//
//
//    }
//
//    /***********************打印************************************/
//    private void print(String content) {
//
//        List<PrinterLines> printLines = new ArrayList();
//
//        //文本打印信息
//        PrinterLines line1 = new PrinterLines();
//        line1.setText(content);
//        line1.setAlignment(0);//对齐：0：左对齐 1：居中 2：右对齐
//        line1.setFeedLines(2);//空行数量
//        line1.setPaintBold(0);//加粗方式 0：不加粗 1：加粗
//        line1.setPaintSize(0, 0);//设置画笔大小 从大小0开始 文字宽度 文字高度
//        printLines.add(line1);
//
//        //二维码打印信息
//        PrinterLines line2 = new PrinterLines();
//        line2.setAlignment(1);
//       // line2.addParam(PrintCmd.PrintQrcode("https://www.baidu.com/", 25, 6, 1));
//        line2.setFeedLines(3);
//        printLines.add(line2);
//
//        HardwareServer.getInstance().print(printLines, new BaseHardware.onResultCallback() {
//            @Override
//            public void onResult(boolean b, String s) {
//                if (b) {
//                    Log.d("print", "打印成功");
//                } else {
//                    Log.e("print error", s);
//                }
//            }
//        });
//    }


}


