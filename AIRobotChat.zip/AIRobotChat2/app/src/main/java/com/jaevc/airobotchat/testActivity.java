package com.jaevc.airobotchat;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.iflytek.aiui.AIUIAgent;
import com.iflytek.aiui.AIUIConstant;
import com.iflytek.aiui.AIUIEvent;
import com.iflytek.aiui.AIUIListener;
import com.iflytek.aiui.AIUIMessage;
import com.jaevc.airobotchat.util.ExceptionUtil;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

public class testActivity extends AppCompatActivity {

    /*摄像头调用常量声明*/
    private static final String TAG = "testActivity";
    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_CAMERA_PERMISSION = 100;

    private int mAIUIState = AIUIConstant.STATE_IDLE;

    private AIUIAgent mAIUIAgent;

    /*语音输入的常量声明*/
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 1;
    private static final int REQUEST_VOICE_INPUT = 2;
    private static final int PERMISSION_REQUEST_CODE = 1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);

        Log.e(TAG,"开始进入测试界面！");
        init(this,mAIUIListener);

    }

    private AIUIListener mAIUIListener = new AIUIListener() {

        @Override
        public void onEvent(AIUIEvent event) {
            switch (event.eventType) {
                //唤醒事件
                case AIUIConstant.EVENT_WAKEUP:
                {
                    Log.i( TAG,  "on event: "+ event.eventType );
                    break;
                }
                //结果事件（包含听写，语义，离线语法结果）
                case AIUIConstant.EVENT_RESULT:
                {
                    try {
                        JSONObject bizParamJson = new JSONObject(event.info);
                        JSONObject data = bizParamJson.getJSONArray("data").getJSONObject(0);
                        JSONObject params = data.getJSONObject("params");
                        JSONObject content = data.getJSONArray("content").getJSONObject(0);

                        if (content.has("cnt_id")) {
                            String cnt_id = content.getString("cnt_id");
                            JSONObject cntJson = new JSONObject(new String(event.data.getByteArray(cnt_id), "utf-8"));
                            String sub = params.optString("sub");
                            if ("nlp".equals(sub)) {
                                // 解析得到语义结果
                                String resultStr = cntJson.optString("intent");
                                Log.i( TAG, resultStr );
                            }
                        }
                    } catch (Exception e) {
//                            e.printStackTrace();
                        ExceptionUtil.printStackTrace(TAG,e);
                    }
                    break;
                }
                //休眠事件
                case AIUIConstant.EVENT_SLEEP:
                {
                    break;
                }
                // 状态事件
                case AIUIConstant.EVENT_STATE: {
                    mAIUIState = event.arg1;
                    if (AIUIConstant.STATE_IDLE == mAIUIState) {
                        // 闲置状态，AIUI未开启
                    } else if (AIUIConstant.STATE_READY == mAIUIState) {
                        // AIUI已就绪，等待唤醒
                    } else if (AIUIConstant.STATE_WORKING == mAIUIState) {
                        // AIUI工作中，可进行交互
                    }
                } break;
                //错误事件
                case AIUIConstant.EVENT_ERROR:
                {
                    //错误事件
                    Log.i( TAG,  "on event: "+ event.eventType );
                    Log.e(TAG, "错误: "+event.arg1+"\n"+event.info );
                    break;
                }
                case AIUIConstant.EVENT_VAD: {
                    if (AIUIConstant.VAD_BOS == event.arg1) {
                        //语音前端点
                    } else if (AIUIConstant.VAD_EOS == event.arg1) {
                        //语音后端点
                    }
                } break;

                case AIUIConstant.EVENT_START_RECORD: {
                    Log.i( TAG,  "on event: "+ event.eventType );
                    Log.i( TAG,  "开始录音： " );
                    //开始录音
                } break;

                case AIUIConstant.EVENT_STOP_RECORD: {
                    Log.i( TAG,  "on event: "+ event.eventType );
                    // 停止录音
                } break;
                default:
                    break;
            }
        }
    };
    public void init(Context context, AIUIListener mAIUIListener){


        Log.e(TAG,"createAgent！");
        mAIUIAgent = AIUIAgent.createAgent(context,getAIUIParams(),mAIUIListener);
        Log.e(TAG,"createAgent success！");
        if( AIUIConstant.STATE_WORKING != mAIUIState ){
            Log.e(TAG,"open AIUI！");
            AIUIMessage wakeupMsg = new AIUIMessage(AIUIConstant.CMD_WAKEUP, 0, 0, "", null);
            mAIUIAgent.sendMessage(wakeupMsg);
            Log.e(TAG,"open AIUI success！");
        }
//
        // 打开AIUI内部录音机，开始录音
        String params = "sample_rate=16000,data_type=audio";
        AIUIMessage writeMsg = new AIUIMessage( AIUIConstant.CMD_START_RECORD, 0, 0, params, null );
        mAIUIAgent.sendMessage(writeMsg);
    }

    private String getAIUIParams() {
        String params = "";
        AssetManager assetManager = getResources().getAssets();
        try {
            InputStream ins = assetManager.open( "cfg/aiui_phone.cfg" );
            byte[] buffer = new byte[ins.available()];

            ins.read(buffer);
            ins.close();

            params = new String(buffer);
        } catch (IOException e) {
            ExceptionUtil.printStackTrace("textTag",e);
//                e.printStackTrace();
        }
        return params;
    }

}
