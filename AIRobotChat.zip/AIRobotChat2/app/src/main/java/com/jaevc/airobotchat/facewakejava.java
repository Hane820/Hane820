package com.jaevc.airobotchat;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.iflytek.WebFaceDetect;
import com.iflytek.aiui.AIUIEvent;
import com.jaevc.airobotchat.util.ExceptionUtil;
import com.jaevc.airobotchat.util.ResponseSkillConstant;
import com.starway.starrobot.aiuiability.AIUIAbility;
import com.starway.starrobot.aiuiability.NLPListener;
import com.starway.starrobot.aiuiability.SpeechHelper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

import java.util.Date;

public class facewakejava extends AppCompatActivity implements SurfaceHolder.Callback, NLPListener {

    private Camera mCamera;
    private SurfaceHolder mHolder;
    private boolean mAutoFocusSupported;
    private boolean mAutoTakePicture;
    public  String imagePath1 = "xxxxxxxxxxxxxxxx";

    private static final int CAMERA_FRONT = 1;
    private static final int CAMERA_BACK = 0;
    private static final int REQUEST_CAMERA_PERMISSION = 2;
    private static final int REQUEST_STORAGE_PERMISSION = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.facewake);


        // 设置屏幕为横屏
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        //获取SurfaceView的id
        SurfaceView surfaceView = (SurfaceView) findViewById(R.id.surfaceView);

        //surfaceview裁剪成圆形
        Object dp1 = 5;
        surfaceView.setOutlineProvider(new CircleViewOutlineProvider(dp1));
        surfaceView.setClipToOutline(true);

        //如果你用的是手机进行调试
        AIUIAbility.getInstance().initPcmRecoderParams(MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                AudioRecord.getMinBufferSize(16000, 2, 2));
        /*****************************/
        AIUIAbility.getInstance().addNLPListener(this);

        AIUIAbility.getInstance().start();
        Log.e(TAG,"AI能力成功启动！");
        //开启休眠功能！
        AIUIAbility.getInstance().setSleepEnable(true);
        //语音合成初始化
        SpeechHelper.getInstance().initSpeech(this);
        //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
        SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
        Log.e(TAG,"初始化Speech完成！");
        // 唤醒AIUI
/***********************************************************/




        //暂时禁用 StrictMode 如果不禁用的话网络端口服务会报错！
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//        StrictMode.setThreadPolicy(policy);

        setContentView(R.layout.facewake);
        mHolder = ((SurfaceView) findViewById(R.id.surfaceView)).getHolder();
        mHolder.addCallback(this);
        mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        mAutoFocusSupported = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_AUTOFOCUS);
        mAutoTakePicture =true;
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_CAMERA_PERMISSION);//1
        }
        // 尝试打开前置摄像头
        mCamera = getCameraInstance(CAMERA_FRONT);
    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        try {
            if(mCamera == null){
                mCamera = Camera.open();}
            mCamera.setPreviewDisplay(holder);
        } catch (IOException e) {
            Log.e(TAG, "Error setting camera preview: " + e.getMessage());
        }
    }
    private Camera getCameraInstance(int cameraId) {
        Camera c = null;
        try {
            c = Camera.open(cameraId);
        } catch (Exception e) {
            // 无法打开指定摄像头时，尝试打开后置摄像头（这里假设后置摄像头ID为0，实际可能因设备而异）
            if (cameraId == CAMERA_FRONT) {
                try {
                    c = Camera.open(CAMERA_BACK);//0
                } catch (Exception e2) {
                    Log.e(TAG, "无法打开后置摄像头: " + e2.getMessage());
                }
            } else {
                Log.e(TAG, "无法打开前置摄像头: " + e.getMessage());
            }
        }
        return c;
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (mHolder.getSurface() == null) {
            return;
        }

        try {
            mCamera.stopPreview();
        } catch (Exception e) {
            Log.e(TAG, "Error stopping camera preview: " + e.getMessage());
        }

        try {
            // 设置相机参数以实现竖屏预览
            Camera.Parameters parameters = mCamera.getParameters();
//            parameters.set("orientation", "portrait");
            if (parameters.getSupportedPreviewFormats()!= null) {
                int orientation = 90; // 旋转90度，将横屏转为竖屏
                mCamera.setDisplayOrientation(orientation);
                parameters.setRotation(orientation);
            }
            mCamera.setParameters(parameters);
            mCamera.setPreviewDisplay(mHolder);
            mCamera.startPreview();
            if (mAutoFocusSupported) {
                mCamera.autoFocus(null);
            }
            if (mAutoTakePicture) {
                mCamera.takePicture(null, null, mPicture);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting camera preview: " + e.getMessage());
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // 释放相机资源
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
    }

    public void startAutoTakePicture() {
        mAutoTakePicture = true;
    }

    public void stopAutoTakePicture() {
        mAutoTakePicture = false;
    }

    private Camera.PictureCallback mPicture = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            // 这里可以处理拍照后的数据
            Bitmap imageBitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException e) {

            }
            imagePath1= savePhoto(imageBitmap,photoFile);
            System.out.println("imagePath11111"+imagePath1);
            try {
                new FaceCompareTask().execute(imagePath1);
            } catch (Exception e) {

            }

        }
    };
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 权限已授予，可以正常进行拍照保存等操作
            } else {
                // 权限被拒绝，可在此处给用户提示，告知无法保存照片等情况
                Toast.makeText(this, "无法保存照片，因为未授予存储权限", Toast.LENGTH_SHORT).show();
            }

        }
    }
    private File createImageFile() throws IOException {
        // 创建一个唯一的文件名
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* 文件名前缀 */
                ".jpg",         /* 后缀 */
                storageDir      /* 目录 */
        );
        return image;
    }

    private String savePhoto(Bitmap bitmap, File file) {

        try {
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    private class FaceCompareTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String imagePath = params[0];
            try {
                WebFaceDetect demo = new WebFaceDetect();
                WebFaceDetect.ResponseData respData = demo.faceContrast(imagePath);
                if (respData!= null && respData.getPayLoad().getFace_detect_result()!= null) {
                    String textBase64 = respData.getPayLoad().getFace_detect_result().getText();
                    String text = new String(Base64.decodeBase64(textBase64));
                    System.out.println("textBase64"+textBase64);
                    Gson gson = new Gson();
                    WebFaceDetect.FaceResult faceResult = gson.fromJson(text, WebFaceDetect.FaceResult.class);
                    System.out.println("faceResult"+faceResult);
                    if (faceResult!= null) {
                        int face_num = faceResult.getFace_num();
                        System.out.println("renlian"+face_num);
                        if (face_num > 0) {
                            return "检测到人脸";
                        } else {
                            return "未检测到人脸";
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if ("检测到人脸".equals(result)) {
                Intent intent1 = new Intent(facewakejava.this, MainActivity.class);
                startActivity(intent1);
            } else {
                runOnUiThread(() -> {
                    AlertDialog.Builder builder = new AlertDialog.Builder(facewakejava.this);
                    builder.setTitle("人脸检测结果");
                    builder.setMessage("未检测到人脸，请重新尝试。");
                    builder.setPositiveButton("确定", (dialog, which) -> {
                        Intent intent1 = new Intent(facewakejava.this, homepagejava.class);
                        startActivity(intent1);
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                });
            }
        }
    }

@Override
    public void onAiuiResponse(String s) {
    Log.i("testTag", "触发onAiuiResponse:" + s);
    try {
        JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
        Log.i("testTag", "jsonObject = " + jsonObject);
        JSONObject textObject = jsonObject.optJSONObject("text");
        if (textObject == null) {
            // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
            String textValue = jsonObject.getJSONObject("nlp").getString("text");
//                Log.i("testTag","获取nlp中的 text 对象= "+textValue);

            textObject = new JSONObject(ExceptionUtil.handleText(textValue));
            Log.i("testTag", "处理后的 text 对象textObject= " + ExceptionUtil.handleText(textValue));
        }
//            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
        JSONObject intentObject = textObject.optJSONObject("intent");

        Log.i("testTag", "获取jsonObject中的 intent 对象= " + intentObject);

        if (intentObject.length() == 0 || TextUtils.equals(intentObject.getString("rc"), "4")) {// 无效问答：无效语义结果，不做回复。
            return;
        }
        //语音识别的文字
        if (intentObject.has("text")) {
            String text = intentObject.getString("text");
            Log.i(TAG, "onAiuiResponse text: " + text);
//                TextView MyspeakView = (TextView) findViewById(R.id.talktextviewtiwen);
//                MyspeakView.setText(text);
        }


        if (intentObject.has("answer")) {

            // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);

            JSONObject answerObject = intentObject.optJSONObject("answer");
            String answerText = answerObject.getString("text");

            //界面显示回答

            Log.e(TAG, "answerText = " + answerText);
//                TextView answer =(TextView) findViewById(R.id.talktextviewanswer);
//                answer.setText(answerText);
            //语音回答
            //SpeechHelper.getInstance().speak(answerText);
        }

        Log.e(TAG, " service =  " + String.valueOf(intentObject.has("service")) + "  " + intentObject.getString("service") + "   " + ResponseSkillConstant.CONTROL_VOICE);
        Log.e(TAG, " 比对 结果 " + String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));

        Log.e(TAG, String.valueOf(textObject.has("service") &&
                TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
        if (intentObject.has("service") &&
                TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
            //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配

            JSONArray semanticArray = intentObject.optJSONArray("semantic");
            JSONObject semanticObject = (JSONObject) semanticArray.get(0);

            String intent = semanticObject.getString("intent");
            Log.e(TAG, " 命令意图 intent = " + intent);
            switch (intent) {
                case "sleep":// AIUI休眠命令
                    AIUIAbility.getInstance().sleep();
                    break;
                case "app_service"://  去访客登记页面
                    Intent intentActivity = new Intent();
                    intentActivity.setClass(facewakejava.this, EnrollActivity.class);
                    startActivity(intentActivity);
                    break;
                case "question_service":
                    Intent intentActivity_question = new Intent();
                    intentActivity_question.setClass(facewakejava.this, TalkActivity.class);
                    startActivity(intentActivity_question);
                case "continue"://播放继续，要与技能中的意图名称匹配
                    Log.e(TAG, "Case");
                    break;
            }
        }
    } catch (Exception e) {
        ExceptionUtil.printStackTrace("testTag", e);
//           e.printStackTrace();
    }



}

    @Override
    public void onAiuiWakeUp() {

    }

    @Override
    public void onAiuiSleep() {
      //  SpeechHelper.getInstance().speak("人脸识别成功");

    }

    @Override
    public void onAiuiEvent(AIUIEvent var1) {

    }

    @Override
    public void onError(int var1) {

    }


}

