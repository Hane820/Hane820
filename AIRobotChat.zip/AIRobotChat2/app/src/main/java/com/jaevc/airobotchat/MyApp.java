package com.jaevc.airobotchat;

import android.app.Application;

import com.starway.starrobot.commonability.RobotType;
import com.starway.starrobot.commonability.StarCommonAbility;
import com.starway.starrobot.commonability.hardware.CenterLightHelper;
import com.starway.starrobot.commonability.hardware.EmojiHelper;
import com.starway.starrobot.commonability.hardware.GPIOHelper;
import com.starway.starrobot.logability.StarLogAbility;
import com.starway.starrobot.logability.log.PartCode;

public class MyApp extends Application {
    // WEBAPI_APPID和WEBAPI_API_KEY: 1:1人脸比对使用
    public static final String WEBAPI_APPID = "ce8e11fe";//已更改
    public static final String WEBAPI_API_KEY = "a1de325162ca268b1386a92080b4a332";

    // webapi 接口地址
    public static final String WEBWFV_URL = "https://api.xfyun.cn/v1/service/v1/image_identify/face_verification";

    @Override
    public void onCreate() {
        super.onCreate();
        init();
    }

    private void init() {
        //日志初始化
        StarLogAbility.getInstance().initAbility(this);
        //基础能力初始化
        StarCommonAbility.getInstance().initAbility(this,
                RobotType.TYPE_TEACHING, new StarCommonAbility.onResultCallback() {
                    @Override
                    public void onResult(boolean isSuccess, String hardCode) {
                        if (isSuccess) {
                            //硬件和业务状态初始化
                            switch (hardCode) {
                                case PartCode.HARDWARE_PARTCODE.CODE_EMOJI:
                                    //设置初始表情
                                    EmojiHelper.doEmojiBase();
                                    break;
                                case PartCode.HARDWARE_PARTCODE.CODE_GPIO:
                                    //默认加载的时候，将拾音方向设置为默认正前方的0度。
                                    GPIOHelper.getInstance().setMainMic(0);
                                    break;
                                case PartCode.HARDWARE_PARTCODE.CODE_CENTER_LIGHT:
                                    //关闭腹部灯带
                                    CenterLightHelper.takeCenterLightOff();
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                });
    }

}
