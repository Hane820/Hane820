package com.jaevc.airobotchat;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.iflytek.aiui.AIUIEvent;
import com.jaevc.airobotchat.EnrollActivity;
import com.jaevc.airobotchat.util.ExceptionUtil;
import com.jaevc.airobotchat.util.ResponseSkillConstant;
import com.starway.starrobot.aiuiability.AIUIAbility;
import com.starway.starrobot.aiuiability.NLPListener;
import com.starway.starrobot.aiuiability.SpeechHelper;

import org.json.JSONArray;
import org.json.JSONObject;

public class GatherActivity extends AppCompatActivity  implements NLPListener {

    private NotificationManager manager;
    private Notification notification;

    //页面多个edittext声明
    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;

    private Button btn;

    //自己定义身份证信息
    private TextView textViewName;
    private TextView textViewIdNumber;
    private TextView textViewAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.gather_activity);

        //打印按钮，跳转去页面后在判断要不要打印
        Button btn = (Button) findViewById(R.id.gatherbuttondayin);
        //提交预约信息按钮
        Button btn1 = (Button) findViewById(R.id.gatherbuttontj);
        //返回上一页按钮
        Button btn2 = (Button) findViewById(R.id.gatherbuttonback);
        //以下是获取edittext输入内容
        editText1 = findViewById(R.id.gathereditextsrxingming);
        editText2 = findViewById(R.id.gathereditextsrphone);
        editText3 = findViewById(R.id.gathereditextsrsfz);
        editText4 = findViewById(R.id.gathereditextyyxm);

        /*
        //获取写死了的身份证信息
        textViewName = findViewById(R.id.gathertextviewsfzname);
        textViewAddress = findViewById(R.id.gathertextviewsfzaddress);
        textViewIdNumber = findViewById(R.id.gathertextviewsfzidnumber);

         */


        //如果你用的是手机进行调试
        AIUIAbility.getInstance().initPcmRecoderParams(MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                AudioRecord.getMinBufferSize(16000, 2, 2));
        /*****************************/
        AIUIAbility.getInstance().addNLPListener(this);

        AIUIAbility.getInstance().start();
        Log.e(TAG,"AI能力成功启动！");
        //开启休眠功能！
        AIUIAbility.getInstance().setSleepEnable(true);
        //语音合成初始化
        SpeechHelper.getInstance().initSpeech(this);
        //设置发音人，这是本地配置，如果开启了自动交流，则会自动播放云端传送过来的音频文件。
        SpeechHelper.getInstance().setVoicer(SpeechHelper.LXY);
        Log.e(TAG,"初始化Speech完成！");
        // 唤醒AIUI
/***********************************************************/


        /*打印新页面，写死了身份证信息*/
        /*
        String name = "张三";
        String idNumber = "123456789012345678";
        String address = "北京市朝阳区";
        textViewName.setText("姓名：" + name);
        textViewIdNumber.setText("身份证号码：" + idNumber);
        textViewAddress.setText("地址：" + address);

         */
        /*上面是打印新页面*/

        //返回上一按钮跳转
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(GatherActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });




        //打印按钮，判断填了东西才执行按钮
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isEmptyEditText(editText1) && !isEmptyEditText(editText2) && !isEmptyEditText(editText3) && !isEmptyEditText(editText4)) {
                    // EditText 中有内容，执行按钮功能
                    btn.setOnClickListener(new View.OnClickListener() {
                        //页面跳转，重复写了
                        @Override
                        public void onClick(View v) {
                            String text1 = editText1.getText().toString();
                            String text2 = editText2.getText().toString();
                            String text3 = editText3.getText().toString();
                            String text4 = editText4.getText().toString();
                            Intent intent = new Intent(GatherActivity.this, CopyActivity.class);
                            intent.putExtra("text1", text1);
                            intent.putExtra("text2", text2);
                            intent.putExtra("text3", text3);
                            intent.putExtra("text4", text4);
                            startActivity(intent);
                        }
                    });

                } else {
                    // EditText 为空，给出提示
                    showToast("请在输入框中填写内容");
                }
            }
        });

        //提交预约信息按钮
        btn1.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View v){

                if (!isEmptyEditText(editText1) && !isEmptyEditText(editText2) && !isEmptyEditText(editText3) && !isEmptyEditText(editText4)) {
                    // EditText 中有内容，执行按钮功能
                    performButtonFunction();
                    sendNotification();
                } else {
                    // EditText 为空，给出提示
                    showToast("请在输入框中填写内容");
                }
            }
        });

    }
    /*上面是onCreate内部*/





    /*Notification发送弹窗通知*/
    private boolean isEmptyEditText(EditText editText) {
        return editText.getText().toString().trim().isEmpty();
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    private void performButtonFunction() {
        // 这里可以执行按钮对应的具体功能
        showToast("预约中，已发送通知");
    }

    //弹窗页面
    private void sendNotification() {
        //Context context = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.yuyue);
        builder.setTitle("预约通知");
        builder.setMessage("成功预约，请等待预约结果，大约1-2天");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 点击确定按钮后的操作
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 点击取消按钮后的操作
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }




    /*以下是摄像头调用*/
    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_CAMERA_PERMISSION = 100;
    /*
        点击事件！
        判断是否拥有相机权限，如果没有就请求相机权限，如果有就使用Intent打开相机。
     */
    public void takePictureIntent(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            dispatchTakePictureIntent();
        }
    }
    /*
        使用Intent打开相机
     */
    public void  dispatchTakePictureIntent(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } catch (ActivityNotFoundException e) {
            // display error state to the user
            Log.e("WarningMsg","相机打开失败!");
        }
    }
    /*
        在拍照完成后，激活该方法，把照片数写入ImageView
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            ImageView imageView = findViewById(R.id.imageviewzhaopian);
            imageView.setImageBitmap(imageBitmap);
        }
    }
    /*
        请求认证回调函数，请求权限成功之后，再次回调打开相机
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();//打开相机
            } else {
                Toast.makeText(this, "相机权限被拒绝", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onAiuiResponse(String s) {
        Log.i("testTag", "触发onAiuiResponse:" + s);
        try {
            JSONObject jsonObject = new JSONObject(new String(s.getBytes(), "utf-8"));
            Log.i("testTag", "jsonObject = " + jsonObject);
            JSONObject textObject = jsonObject.optJSONObject("text");
            if (textObject == null) {
                // 传过来的jsonObject中的text的值会被转换成字符串，而不是对象。如果是字符串则重新处理成可以被转换程json对象的字符串
                String textValue = jsonObject.getJSONObject("nlp").getString("text");
//                Log.i("testTag","获取nlp中的 text 对象= "+textValue);

                textObject = new JSONObject(ExceptionUtil.handleText(textValue));
                Log.i("testTag", "处理后的 text 对象textObject= " + ExceptionUtil.handleText(textValue));
            }
//            Log.i("testTag","获取jsonObject中的 text 对象= "+intentObject);
            JSONObject intentObject = textObject.optJSONObject("intent");

            Log.i("testTag", "获取jsonObject中的 intent 对象= " + intentObject);

            if (intentObject.length() == 0 || TextUtils.equals(intentObject.getString("rc"), "4")) {// 无效问答：无效语义结果，不做回复。
                return;
            }
            //语音识别的文字
            if (intentObject.has("text")) {
                String text = intentObject.getString("text");
                Log.i(TAG, "onAiuiResponse text: " + text);
                TextView MyspeakView = (TextView) findViewById(R.id.talktextviewtiwen);
                MyspeakView.setText(text);
            }


            if (intentObject.has("answer")) {

                // findViewById(R.id.answerArea).setVisibility(View.VISIBLE);

                JSONObject answerObject = intentObject.optJSONObject("answer");
                String answerText = answerObject.getString("text");

                //界面显示回答

                Log.e(TAG, "answerText = " + answerText);
                TextView answer =(TextView) findViewById(R.id.talktextviewanswer);
                answer.setText(answerText);
                //语音回答
                //SpeechHelper.getInstance().speak(answerText);
            }

            Log.e(TAG, " service =  " + String.valueOf(intentObject.has("service")) + "  " + intentObject.getString("service") + "   " + ResponseSkillConstant.CONTROL_VOICE);
            Log.e(TAG, " 比对 结果 " + String.valueOf(TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));

            Log.e(TAG, String.valueOf(textObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)));
            if (intentObject.has("service") &&
                    TextUtils.equals(intentObject.getString("service"), ResponseSkillConstant.CONTROL_VOICE)) {
                //自定义技能回复，"XT.PlayerCtrl"是技能名称，注意要与自己配置的技能名称匹配

                JSONArray semanticArray = intentObject.optJSONArray("semantic");
                JSONObject semanticObject = (JSONObject) semanticArray.get(0);

                String intent = semanticObject.getString("intent");
                Log.e(TAG, " 命令意图 intent = " + intent);
                switch (intent) {
                    case "sleep":// AIUI休眠命令
                        AIUIAbility.getInstance().sleep();
                        break;
                    case "app_service"://  去访客登记页面
                        Intent intentActivity = new Intent();
                        intentActivity.setClass(GatherActivity.this, EnrollActivity.class);
                        startActivity(intentActivity);
                        break;
                    case "question_service":
                        Intent intentActivity_question = new Intent();
                        intentActivity_question.setClass(GatherActivity.this, TalkActivity.class);
                        startActivity(intentActivity_question);
                    case "continue"://播放继续，要与技能中的意图名称匹配
                        Log.e(TAG, "Case");
                        break;
                }
            }
        }catch (Exception e){
            ExceptionUtil.printStackTrace("testTag",e);
//           e.printStackTrace();
        }

    }

    @Override
    public void onAiuiWakeUp() {
        SpeechHelper.getInstance().speak("接下来要采集您的信息，请按照界面指引填写");

    }

    @Override
    public void onAiuiSleep() {

    }

    @Override
    public void onAiuiEvent(AIUIEvent var1) {

    }

    @Override
    public void onError(int var1) {

    }
}


