package com.jaevc.airobotchat;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.starway.starrobot.commonability.camera.CameraHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 相机拍照工具，会调用相机拍照，并将拍照结果保存在/sdcard/Download/LoveRobot/，同时会将拍照的bitmap返回给前面的界面
 */
public class CameraActivity extends AppCompatActivity implements CameraHelper.GetBitmapListener, CameraHelper.OnCameraPrepareListener {


    /**
     * 摄像头帮助类
     */
    private CameraHelper mCameraHelper;

    /**
     * 是否正在拍照中
     */
    private boolean mPictureTakeStatus = false;

    /**
     * SurfaceView
     */
    private FrameLayout mSurfaceView;

    /**
     * 照片展示
     */
    private ImageView mPicView;

    /**
     * 返回按钮
     */
    private Button mBackBtn;

    /**
     * 拍照按钮
     */
    private Button mShutterBtn;

    /**
     * 裁剪按钮
     */
    private Button mCropBtn;

    /**
     * 拍照图片
     */
    private Bitmap mBitmap;

    private CameraManager mCameraManager;
    private String[] mCameraIdList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        mCameraHelper = new CameraHelper(this);
        initData();
        initView();
    }

    private void initData() {
        mCameraHelper = new CameraHelper(this);
        mCameraManager = (CameraManager) getApplicationContext().getSystemService(Context.CAMERA_SERVICE);
        try {
            mCameraIdList = mCameraManager.getCameraIdList();
        } catch (CameraAccessException e) {
            throw new RuntimeException(e);
        }
    }

    protected void initView() {
        mPicView = (ImageView) findViewById(R.id.iv_pic);
        mSurfaceView = (FrameLayout) findViewById(R.id.surface_frame);
        mBackBtn = (Button) findViewById(R.id.btn_back);
        mCropBtn = (Button) findViewById(R.id.btn_crop);
        mShutterBtn = (Button) findViewById(R.id.btn_shutter);
        //初始化摄像头
        initCamera();

    }


    /**
     * 处理摄像头初始化等操作
     */
    private void initCamera() {
        try {
            mCameraHelper.setGetBitmapListener(this);
            mCameraHelper.setOnCameraPrepareListener(this);
            if (mCameraIdList == null || mCameraIdList.length == 0) {
                showToast("未检测到相机");
                finish();
            } else {
                for (String s : mCameraIdList) {
                    Log.d("CameraActivity", "mCameraIdList: " + s);
                }
                /**
                 * 开发平台和机器人本体会有差异:
                 * 在机器人本体上相机ID为固定ID（CameraHelper.CameraID.CAMERA_FRONT、CameraHelper.CameraID.CAMERA_BACK）;
                 * 在开发平台相机ID不固定，所以需要提前获取相机ID
                 */
                mCameraHelper.openCamera(mSurfaceView, Integer.parseInt(mCameraIdList[0]));
                //     mCameraHelper.openCamera(mSurfaceView, CameraHelper.CameraID.CAMERA_BACK);
            }
        } catch (Exception ex) {
            showToast("初始化摄像头出现异常：" + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * 获取图片
     */
    @Override
    public void getBitmap(final Bitmap bitmap) {
        mBitmap = bitmap;
        mPicView.setImageBitmap(bitmap);
        mPicView.setVisibility(View.VISIBLE);
        mCropBtn.setVisibility(View.VISIBLE);
        mBackBtn.setVisibility(View.VISIBLE);
        mShutterBtn.setVisibility(View.INVISIBLE);
        mPictureTakeStatus = false;

    }

    /**
     * 拍照点击事件
     **/
    public void shutterClick(View view) {
        if (mPictureTakeStatus) {
            return;
        }
        mPictureTakeStatus = true;
        mCameraHelper.takePreView();
    }

    public void cropBtnClick(View view) {
        Intent intent = new Intent();
        intent.putExtra("bitmap", saveBitmap());
        setResult(RESULT_OK, intent);
        mCameraHelper.closeCamera();
        CameraActivity.this.finish();

    }

    /**
     * 保存方法
     */
    public String saveBitmap() {
        File f = new File("/sdcard/Download/LoveRobot/", System.currentTimeMillis() + ".jpg");
        f.mkdirs();
        if (f.exists()) {
            f.delete();
        }

        try {
            f.createNewFile();
            FileOutputStream out = new FileOutputStream(f);
            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(CameraActivity.this, "保存成功,文件路径:Download/LoveRobot/", Toast.LENGTH_LONG).show();
                }
            });
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return f.getAbsolutePath();
    }

    /**
     * 返回
     *
     * @param view
     */
    public void backBtnClick(View view) {
        mPicView.setVisibility(View.GONE);
        mBackBtn.setVisibility(View.GONE);
        mCropBtn.setVisibility(View.GONE);
        mShutterBtn.setVisibility(View.VISIBLE);
    }


    /**
     * 初始化监听
     */
    @Override
    public void prepare() {
        mShutterBtn.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCameraHelper.closeCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }
}

