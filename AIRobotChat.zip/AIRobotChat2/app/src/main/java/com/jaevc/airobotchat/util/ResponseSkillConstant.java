package com.jaevc.airobotchat.util;

public interface ResponseSkillConstant {

    /**
     * 关键词问答技能
     */
    public static final String CHAT_KQA = "UBotQa";
    /**
     * 服务预约技能
     */
    public static final String CHAT_YY = "OS19424451228.chat";
    /**
     * 语音控制
     */
    public static final String CONTROL_VOICE = "OS19424451228.voiceControl";



}
