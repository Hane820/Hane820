package com.jaevc.airobotchat.util;

import android.util.Log;

/**
 *
   用于处理安卓开发中的异常信息的通用工具类
 */
public class ExceptionUtil {

    /**
     *用于打印捕获异常的 StackTrace信息，通过设置tag标签名，便于在logcat中快速查找异常信息
     * @param tag  标签名
     * @param e  异常类
     */
    public static void printStackTrace(String tag,Exception e){

        StackTraceElement[] stackTrace = e.getStackTrace();
        StringBuilder stackTraceContent = new StringBuilder();
        for (StackTraceElement element : stackTrace) {
            stackTraceContent.append(element.toString()).append("\n");
        }
// 现在stackTraceContent包含了StackTrace的内容，但没有打印出来
        String stackTraceString = stackTraceContent.toString();
// 可以根据需要对stackTraceString进行进一步处理或存储等操作
        Log.e(tag,e.getMessage()+":"+stackTraceString);

    }

    /**
     * 掉字符串s最外层的双引号，并去掉转义符\
     * @param s
     * @return
     */
    public static String handleText(String s){
        if (s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length() - 1);
        }

        // 去掉转义符
        s = s.replace("\\\"", "\"");
        return s;
    }
}
