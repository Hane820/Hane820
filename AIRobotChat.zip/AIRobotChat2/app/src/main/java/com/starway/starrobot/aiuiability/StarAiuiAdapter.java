package com.starway.starrobot.aiuiability;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.AudioRecord;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import com.iflytek.aiui.AIUIAgent;
import com.iflytek.aiui.AIUIConstant;
import com.iflytek.aiui.AIUIEvent;
import com.iflytek.aiui.AIUIListener;
import com.iflytek.aiui.AIUIMessage;
import com.iflytek.aiui.AIUISetting;
import com.starway.starrobot.face.FileUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

public class StarAiuiAdapter extends AIUIAdapter implements AIUIListener {
    private static final String TAG = "StarAiuiAdapter";
    private static final String PATH = BuildConfig.AIUI_CFG_PATH;
    private PcmRecorder mRecorder;
    private final Context mContext;
    private Handler mHandler;
    private UserParamsSetCallback callback;
    public AIUIAdapter.ParseListener mParseListener;
    protected boolean mIsSleepEnabled = true;
    protected AIUIAdapter.AIUITTSEvent mAIUITTSEventListener;
    protected AIUIAgent mAIUIAgent;
    private final PcmRecorder.PcmListener mPcmListener = new PcmRecorder.PcmListener() {
        public void onPcm(byte[] data, int dataLen) {
            if (null != data && dataLen != 0) {
                byte[] audio = new byte[dataLen];
                System.arraycopy(data, 0, audio, 0, dataLen);
                if (null != StarAiuiAdapter.this.mAIUIAgent) {
                    synchronized(StarAiuiAdapter.this.mAIUIAgent) {
                        String userParams = StarAiuiAdapter.this.callback.getUserParams(false);
                        if (!TextUtils.isEmpty(userParams)) {
                            AIUIMessage setMsg = new AIUIMessage(10, 0, 0, userParams, (byte[])null);
                            StarAiuiAdapter.this.mAIUIAgent.sendMessage(setMsg);
                        }

                        String params = "data_type=audio,sample_rate=16000,topn=10";
                        AIUIMessage msg = new AIUIMessage(2, 0, 0, params, audio);
                        StarAiuiAdapter.this.mAIUIAgent.sendMessage(msg);
                    }
                }
            }

        }
    };

    protected void setUserParamsCallback(UserParamsSetCallback paramsCallback) {
        this.callback = paramsCallback;
    }

    /** @deprecated */
    @Deprecated
    public void setSleepEnable(boolean isEnable) {
        this.mIsSleepEnabled = isEnable;
    }

    public void setOnAIUITTSEventListener(AIUIAdapter.AIUITTSEvent event) {
        this.mAIUITTSEventListener = event;
    }

    public void sendText(String text) {
        String userParams = this.callback.getUserParams(true);
        if (!TextUtils.isEmpty(userParams)) {
            AIUIMessage setMsg = new AIUIMessage(AIUIConstant.CMD_SET_PARAMS, 0, 0, userParams, (byte[])null);
            this.mAIUIAgent.sendMessage(setMsg);
        }

        String params = "data_type=text,topn=10";

        try {
            byte[] data = text.getBytes("utf-8");
            AIUIMessage msg = new AIUIMessage(AIUIConstant.CMD_WRITE, 0, 0, params, data);
            this.mAIUIAgent.sendMessage(msg);
        } catch (UnsupportedEncodingException var5) {
            Log.e("StarAiuiAdapter", "aiui sendText UnsupportedEncodingException!");
        }

    }

    public void clearDialogHistory() {
        AIUIMessage clearDialogMsg = new AIUIMessage(AIUIConstant.CMD_CLEAN_DIALOG_HISTORY, 0, 0, "", (byte[])null);
        this.mAIUIAgent.sendMessage(clearDialogMsg);
    }

    public StarAiuiAdapter(Context context) {
        this.mContext = context;
    }

    public AIUIAgent getAIUIAgent() {
        return this.mAIUIAgent;
    }

    public void init(AIUIAdapter.ParseListener listener) {
        this.mParseListener = listener;
        this.mHandler = new Handler();

        // 将ivw下示例唤醒配置vtn.ini和示例唤醒资源res.bin(唤醒词）拷贝到文件系统中。
        FileUtil.copyAssetFolder(this.mContext.getApplicationContext(),"ivw", "/sdcard/AIUI/ivw");

        // 读取aiui配置文件
        String config = readAssetsCfg(this.mContext.getApplicationContext());

        Log.e("testTag","初始化AIUIAgent之前：上传设备SN码："+Build.SERIAL);
        AIUISetting.setSystemInfo(AIUIConstant.KEY_SERIAL_NUM, Build.SERIAL);
//        Log.e("testTag","config = "+config);
        this.mAIUIAgent = AIUIAgent.createAgent(this.mContext.getApplicationContext(), config, this);
        Log.e("testTag","mAIUIAgent = "+this.mAIUIAgent);
        if (null == this.mAIUIAgent) {
            throw new IllegalStateException("aiui agent create failed");
        } else {
//            Log.e("testTag","null == this.mRecorder?  mRecorder= "+this.mRecorder);
            if (null == this.mRecorder) {
                String phoneInfo = Build.PRODUCT;
                Log.e("testTag","phoneInfo = "+phoneInfo);
                if (!TextUtils.isEmpty(phoneInfo) && phoneInfo.startsWith("rk3588")) {
                    this.mRecorder = PcmRecorder.createRecorder(1, 16000, 16, 2, AudioRecord.getMinBufferSize(16000, 12, 2));
                } else {
                    this.mRecorder = PcmRecorder.createRecorder(1, 16000, 12, 2, AudioRecord.getMinBufferSize(16000, 12, 2));
                }
                Log.e("testTag","创建mRecorder成功: "+this.mRecorder);
            }

        }
    }

    public void start() {
        if (this.mRecorder != null) {
            this.mRecorder.startRecording(this.mPcmListener);
        }

        this.mHandler.postDelayed(new Runnable() {
            public void run() {
                if (StarAiuiAdapter.this.mAIUIAgent != null) {
                    AIUIMessage startMsg = new AIUIMessage(AIUIConstant.CMD_START, 0, 0, (String)null, (byte[])null);
                    StarAiuiAdapter.this.mAIUIAgent.sendMessage(startMsg);
                    AIUIMessage wakeupMsg = new AIUIMessage(AIUIConstant.CMD_WAKEUP, 0, 0, "", (byte[])null);
                    StarAiuiAdapter.this.mAIUIAgent.sendMessage(wakeupMsg);
                    StarAiuiAdapter.this.clearDialogHistory();
                }

            }
        }, 1000L);
    }

    /**
     * 关闭AIUI
     */
    public void stop() {
        AIUIMessage paramsMsg = new AIUIMessage(AIUIConstant.CMD_RESET_WAKEUP, 0, 0, (String)null, (byte[])null);
        this.mAIUIAgent.sendMessage(paramsMsg);
        if (this.mRecorder != null) {
            this.mRecorder.stopRecording();
        }

    }

    /**
     * 重置AIUI
     */
    public void reset() {
        AIUIMessage resetWakeupMsg = new AIUIMessage(AIUIConstant.CMD_RESET_WAKEUP, 0, 0, "", (byte[])null);
        this.mAIUIAgent.sendMessage(resetWakeupMsg);
    }


    /**
     * 唤醒AIUI，
     */
    public void resetSleep() {
        AIUIMessage wakeupMsg = new AIUIMessage(AIUIConstant.CMD_WAKEUP, 0, 0, "", (byte[])null);
        this.mAIUIAgent.sendMessage(wakeupMsg);
    }

    /**
     * 将AIUI状态重置为STATE_READY就绪状态， 这个状态下不处理数据，需要语音唤醒或者发送CMD_WAKEUP手动唤醒
     */
    public void resetReady(){
        AIUIMessage wakeupMsg = new AIUIMessage(AIUIConstant.CMD_START, 0, 0, "", (byte[])null);
        this.mAIUIAgent.sendMessage(wakeupMsg);
    }

    protected void initAudio(int audioSource, int sampleRateInHz, int channelConfig, int audioFormat, int minBufferSize) {
        this.releaseRecord();
        this.mRecorder = PcmRecorder.createRecorder(audioSource, sampleRateInHz, channelConfig, audioFormat, minBufferSize);
    }

    protected void releaseRecord() {
        if (null != this.mRecorder) {
            this.mRecorder.destroy();
        }

    }

    public void onEvent(AIUIEvent event) {
        switch (event.eventType) {
            case AIUIConstant.EVENT_RESULT:
                if (null != this.mParseListener) {
                    Log.e(TAG,"onEvent 回调函数！onAiuiResponse");
                    this.mParseListener.onAiuiResponse(event);
                }
                break;
            case AIUIConstant.EVENT_ERROR:
                int errorCode = event.arg1;
                if (null != this.mParseListener) {
                    this.mParseListener.onError(errorCode);
                }
            case AIUIConstant.EVENT_STATE:
            case AIUIConstant.EVENT_VAD:
            case AIUIConstant.EVENT_BIND_SUCCESS:
            case AIUIConstant.EVENT_CMD_RETURN:
            case AIUIConstant.EVENT_AUDIO:
            case AIUIConstant.EVENT_PRE_SLEEP:
            case AIUIConstant.EVENT_START_RECORD:
            case AIUIConstant.EVENT_CONNECTED_TO_SERVER:
            case AIUIConstant.EVENT_SERVER_DISCONNECTED:
            default:
                break;
                case AIUIConstant.EVENT_STOP_RECORD:
                    Log.e(TAG,"onEvent 回调函数！录音结束！");
            case AIUIConstant.EVENT_WAKEUP:
                if (this.mIsSleepEnabled && null != this.mParseListener) {
                    Log.e(TAG,"onEvent 回调函数！onAiuiWakeUp");

                    this.mParseListener.onAiuiWakeUp();
                }
                break;
            case AIUIConstant.EVENT_SLEEP:
                // 如果开启了休眠模式，这个是自己配置的 mIsSleepEnabled这个属性
                if (this.mIsSleepEnabled && null != this.mParseListener) {
                    Log.e(TAG,"onEvent 回调函数！onAiuiSleep");
                    this.mParseListener.onAiuiSleep();
                } else { // 如果没有开启休眠模式，则重新唤醒AIUI
                    this.resetSleep();
                }
                break;
            case AIUIConstant.EVENT_TTS:
                if (null != this.mAIUITTSEventListener) {
                    Log.e(TAG,"onEvent 回调函数！onEvent");
                    this.mAIUITTSEventListener.onEvent(event);
                }
        }

    }

    /**
     * 读取cfg/aiui.cfg配置文件
     * @param context
     * @return
     */
    private static String readAssetsCfg(Context context) {
        String content = "";
        AssetManager assetManager = context.getResources().getAssets();

        try {
            InputStream ins = assetManager.open(PATH);
            byte[] buffer = new byte[ins.available()];
            ins.read(buffer);
            ins.close();
            content = new String(buffer, "utf-8");
        } catch (IOException var5) {
            Log.e("StarAiuiAdapter", "readAssetsCfg IOException");
        }

        return content;
    }

    interface UserParamsSetCallback {
        String getUserParams(Boolean var1);
    }
}
