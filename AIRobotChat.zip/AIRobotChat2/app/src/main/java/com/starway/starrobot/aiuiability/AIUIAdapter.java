package com.starway.starrobot.aiuiability;

import com.iflytek.aiui.AIUIEvent;

public abstract class AIUIAdapter {
    public AIUIAdapter() {
    }

    abstract void init(ParseListener var1);

    abstract void start();

    abstract void stop();

    abstract void reset();

    abstract void resetSleep();

    abstract void sendText(String var1);

    public abstract void clearDialogHistory();

    public interface AIUITTSEvent {
        void onEvent(AIUIEvent var1);
    }

    public interface ParseListener {
        void onAiuiResponse(AIUIEvent var1);

        void onAiuiWakeUp();

        void onAiuiSleep();

        void onAiuiEvent(AIUIEvent var1);

        void onError(int var1);
    }
}
