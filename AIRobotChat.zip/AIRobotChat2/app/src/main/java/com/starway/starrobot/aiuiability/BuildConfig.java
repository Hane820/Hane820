package com.starway.starrobot.aiuiability;

public final class BuildConfig {

    // 存储assets/cfg/aiui_phone.cfg 配置文件
    public static final String AIUI_CFG_PATH = "cfg/aiui_phone.cfg";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.starway.starrobot.aiuiability";
    /** @deprecated */
    @Deprecated
    public static final String APPLICATION_ID = "com.starway.starrobot.aiuiability";
    public static final String BUILD_TYPE = "release";
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";

    public BuildConfig() {
    }
}
