package com.starway.starrobot.aiuiability;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class SpeechHelper implements TTS.OnSpeakErrorListener {

    //发音人文档列表 https://aiui-doc.xf-yun.com/project-1/doc-93/
    /**
     * 发音人聆小樱
     */
    public static final String LXY = "x4_lingxiaoying_em_v2";
    /**
     * 发音人聆小璇
     */
    public static final String LXX = "x4_lingxiaoxuan_chat";
    /**
     * 发音人小娟
     */
    public static final String XJ = "x2_xiaojuan";
    /**
     * 发音人小姐姐
     */
    public static final String XJJ = "x_dangdang";
    /**
     * 发音人小哥哥
     */
    public static final String XGG = "x_qige";

    private static final String TAG = "SpeechHelper";
    private static final String PREFER_NAME = "com.iflytek.robot.voicesetting";
    private boolean mIsSpeechEnable = true;
    private static volatile SpeechHelper instance;
    private TTS mSpeak;

    public void setSpeechEnable(boolean enable) {
        this.mIsSpeechEnable = enable;
    }

    public static SpeechHelper getInstance() {
        if (null == instance) {
            Class var0 = SpeechHelper.class;
            synchronized(SpeechHelper.class) {
                if (null == instance) {
                    instance = new SpeechHelper();
                }
            }
        }

        return instance;
    }

    private SpeechHelper() {
    }

    public void initSpeech(Context context) {
        SharedPreferences configParams = context.getApplicationContext().getSharedPreferences(PREFER_NAME, 0);
        this.mSpeak = TTS.getInstance();
        this.mSpeak.setOnSpeakErrorListener(this);
        this.mSpeak.initSpeakPar(context, configParams);
    }

    public void speak(String text) {
        this.speak(text, (TTS.OnSpeakCallback)null);
    }

    public void speak(String text, TTS.OnSpeakCallback callback) {
        this.speak(text, (String)null, callback);
    }

    public void speak(String text, String speaker, TTS.OnSpeakCallback callback) {
        if (this.mIsSpeechEnable && this.mSpeak != null) {
            this.mSpeak.speak(text, speaker, callback);
        }

    }

    public void release() {
        if (null != this.mSpeak) {
            this.mSpeak.stopSpeaking();
            this.mSpeak = null;
        }

    }

    public void stopSpeak() {
        if (this.mSpeak != null) {
            this.mSpeak.stopSpeaking();
        }

    }

    public void stopSpeak(boolean removeCallback) {
        if (removeCallback) {
            this.mSpeak.removeCallbacks();
        }

        if (this.mSpeak != null) {
            this.mSpeak.stopSpeaking();
        }

    }

    public void resumeSpeaking() {
        if (null != this.mSpeak) {
            this.mSpeak.resumeSpeaking();
        }

    }

    public void pauseSpeaking() {
        if (null != this.mSpeak) {
            this.mSpeak.pauseSpeaking();
        }

    }

    public void onSpeakError(String error) {
        Log.e("SpeechHelper", "onSpeakError:" + error);
    }

    public void setVoicer(String name) {
        if (null != this.mSpeak) {
            this.mSpeak.setVoicer(name);
        }

    }

    public void setTone(String tone) {
        if (null != this.mSpeak) {
            this.mSpeak.setTone(tone);
        }

    }

    public void setSpeed(String speed) {
        if (null != this.mSpeak) {
            this.mSpeak.setSpeed(speed);
        }

    }

    public void setVolume(String volume) {
        if (null != this.mSpeak) {
            this.mSpeak.setVolume(volume);
        }

    }

    public boolean isSpeaking() {
        return this.mSpeak != null && this.mSpeak.isSpeaking();
    }
}
