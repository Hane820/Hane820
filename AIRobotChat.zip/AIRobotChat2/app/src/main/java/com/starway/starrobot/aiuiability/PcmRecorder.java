package com.starway.starrobot.aiuiability;

import android.media.AudioRecord;
import android.util.Log;

public class PcmRecorder {
    /**
     * AIUI麦克风处于播放状态
     */
    public static final int SPEAKER_STATE_ON = 1;
    /**
     * AIUI麦克风处于空闲状态
     */
    public static final int SPEAKER_STATE_OFF = 0;
    /**
     * AIUI麦克风状态管理
     */
    private static int speakerState = 2;
    private AudioRecord mAudioRecord;
    private int mMinBufferSize;
    private PcmListener mListener;
    private RecordThread mRecordThread;
    private static PcmRecorder instance;

    public static PcmRecorder createRecorder(int audioSource, int sampleRateInHz, int channelConfig, int audioFormat, int minBufferSize) {
        if (null == instance) {
            instance = new PcmRecorder(audioSource, sampleRateInHz, channelConfig, audioFormat, minBufferSize);
        }

        return instance;
    }

    private PcmRecorder(int audioSource, int sampleRateInHz, int channelConfig, int audioFormat, int minBufferSize) {
        Log.d("PcmRecorder", "channelConfig: " + channelConfig);
        this.mMinBufferSize = minBufferSize;
        this.mAudioRecord = new AudioRecord(audioSource, sampleRateInHz, channelConfig, audioFormat, this.mMinBufferSize);
    }

    public void startRecording(PcmListener listener) {
        synchronized(this) {
            this.mListener = listener;
            if (null == this.mRecordThread) {
                this.mRecordThread = new RecordThread();
                this.mRecordThread.start();
            }

        }
    }

    public void stopRecording() {
        synchronized(this) {
            if (null != this.mRecordThread) {
                this.mRecordThread.stopRun();
                this.mRecordThread = null;
            }

        }
    }

    public void destroy() {
        synchronized(this) {
            if (null != instance) {
                if (null != this.mRecordThread) {
                    this.mRecordThread.stopRun();
                    this.mRecordThread = null;
                }

                while(this.mAudioRecord.getRecordingState() != 1) {
                    Log.d("PcmRecorder", "mAudioRecord.getRecordingState() = " + this.mAudioRecord.getRecordingState());
                }

                this.mAudioRecord.release();
                this.mAudioRecord = null;
                instance = null;
            }

        }
    }

    private class RecordThread extends Thread {
        private boolean mStop;

        private RecordThread() {
            this.mStop = false;
        }

        private void stopRun() {
            this.mStop = true;
        }

        public void run() {
            if (null != PcmRecorder.this.mAudioRecord) {
                PcmRecorder.this.mAudioRecord.startRecording();
            }

            byte[] buffer = new byte[PcmRecorder.this.mMinBufferSize];

            while(!this.mStop) {
                PcmRecorder.this.mAudioRecord.read(buffer, 0, PcmRecorder.this.mMinBufferSize);
                if (null != PcmRecorder.this.mListener) {
                    PcmRecorder.this.mListener.onPcm(buffer, buffer.length);
                }
            }

            if (null != PcmRecorder.this.mAudioRecord) {
                PcmRecorder.this.mAudioRecord.stop();
            }

        }
    }

    public interface PcmListener {
        void onPcm(byte[] var1, int var2);
    }
}
