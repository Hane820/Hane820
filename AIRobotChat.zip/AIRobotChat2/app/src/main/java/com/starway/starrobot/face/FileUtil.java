package com.starway.starrobot.face;


import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 文件操作工具类
 */
public class FileUtil {
    /**
     * 读取文件内容为二进制数组
     *
     * @param filePath
     * @return
     * @throws IOException
     */
    public static byte[] read(String filePath) throws IOException {
        InputStream in = new FileInputStream(filePath);
        byte[] data = inputStream2ByteArray(in);
        in.close();

        return data;
    }

    /**
     * 流转二进制数组
     *
     * @param in
     * @return
     * @throws IOException
     */
    public static byte[] inputStream2ByteArray(InputStream in) throws IOException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024 * 4];
        int n = 0;
        while ((n = in.read(buffer)) != -1) {
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    /**
     * 保存文件
     *
     * @param filePath
     * @param fileName
     * @param content
     */
    public static void save(String filePath, String fileName, byte[] content) {
        try {
            File filedir = new File(filePath);
            if (!filedir.exists()) {
                filedir.mkdirs();
            }
            File file = new File(filedir, fileName);
            OutputStream os = new FileOutputStream(file);
            os.write(content, 0, content.length);
            os.flush();
            os.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * bitmap转byte[]
     * * @param bm
     *
     * @return
     */
    public static byte[] Bitmap2Bytes(Bitmap bm) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
        return baos.toByteArray();
    }

    public static void copyAssetFolder(Context context, String srcFolder, String destFolder) {
        AssetManager assetManager = context.getResources().getAssets();
        try{
            String[] files = assetManager.list(srcFolder);
            new File(destFolder).mkdirs(); // Create destination folder if it doesn't exist

            for (String file : files) {
                String srcPath = srcFolder + "/" + file;
                String destPath = destFolder + "/" + file;

                // Check if the current item is a directory or a file
                if (assetManager.list(srcPath).length > 0) {
                    // It's a directory, recurse into it
                    copyAssetFolder(context, srcPath, destPath);
                } else {
                    // It's a file, copy it
                    copyAssetFile(context, srcPath, destPath);
                }
            }
        }catch (IOException e) {

            Log.e("StarAiuiAdapter", "copyAssetFolder IOException: from "+srcFolder+" to "+destFolder);
        }


    }

    private static void copyAssetFile(Context context, String srcFile, String destFile) throws IOException {
        AssetManager assetManager = context.getAssets();
        InputStream in = assetManager.open(srcFile);
        OutputStream out = new FileOutputStream(new File(destFile));

        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
        in.close();
        out.flush();
        out.close();
    }
}
