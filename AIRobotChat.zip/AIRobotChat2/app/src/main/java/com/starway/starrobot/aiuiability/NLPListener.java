package com.starway.starrobot.aiuiability;

import com.iflytek.aiui.AIUIEvent;

public interface NLPListener {
    void onAiuiResponse(String var);

    void onAiuiWakeUp();

    void onAiuiSleep();

    void onAiuiEvent(AIUIEvent var1);

    void onError(int var1);
}
