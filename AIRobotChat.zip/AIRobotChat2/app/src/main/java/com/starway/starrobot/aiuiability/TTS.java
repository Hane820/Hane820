package com.starway.starrobot.aiuiability;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;
import com.iflytek.aiui.AIUIAgent;
import com.iflytek.aiui.AIUIEvent;
import com.iflytek.aiui.AIUIMessage;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.atomic.AtomicBoolean;

public class TTS implements AIUIAdapter.AIUITTSEvent {
    private final String TAG = "TTS";
    private SharedPreferences mSharedPreferences;
    private AIUIAgent mAIUIAgent;
    private String mVoicer = "jiajia";
    private String mTone;
    private String mSpeed;
    private String mVolume;
    private String mText;
    private OnSpeakCallback mOnSpeakCallback;
    private OnSpeakErrorListener mOnSpeakErrorListener;
    private AtomicBoolean isSpeak = new AtomicBoolean(false);
    private static volatile TTS voiceSpeak = null;

    private TTS() {
    }

    public static TTS getInstance() {
        if (voiceSpeak == null) {
            Class var0 = TTS.class;
            synchronized(TTS.class) {
                if (voiceSpeak == null) {
                    voiceSpeak = new TTS();
                }
            }
        }

        return voiceSpeak;
    }

    public void setOnSpeakErrorListener(OnSpeakErrorListener listener) {
        this.mOnSpeakErrorListener = listener;
    }

    public void removeCallbacks() {
        this.mOnSpeakCallback = null;
    }

    protected void initSpeakPar(Context context, SharedPreferences params) {
        this.mSharedPreferences = params;
        this.mVoicer = this.mSharedPreferences.getString("Informant", this.mVoicer);
        this.mSpeed = this.mSharedPreferences.getString("soundVelocity", "50");
        this.mVolume = this.mSharedPreferences.getString("soundVolume", "50");
        this.mTone = this.mSharedPreferences.getString("tone", "50");

        try {
            StarAiuiAdapter mAdapter = AIUIAbility.getInstance().getAIUIAdapter();
            mAdapter.setOnAIUITTSEventListener(this);
            this.mAIUIAgent = mAdapter.getAIUIAgent();
            if (null == this.mAIUIAgent) {
                this.errorSpeak("AIUIAgent has not create yet, can't use aiui tts");
            }
        } catch (Exception var4) {
            Log.e("TTS", "get aiui agent failure");
        }

    }

    protected void setVoicer(String name) {
        this.mVoicer = name;
        SharedPreferences.Editor editor = this.mSharedPreferences.edit();
        editor.putString("Informant", name);
        editor.commit();
    }

    protected void setTone(String vone) {
        this.mTone = vone;
        SharedPreferences.Editor editor = this.mSharedPreferences.edit();
        editor.putString("tone", vone);
        editor.commit();
    }

    protected boolean isSpeaking() {
        return this.isSpeak.get();
    }

    protected void setSpeed(String speed) {
        this.mSpeed = speed;
        SharedPreferences.Editor editor = this.mSharedPreferences.edit();
        editor.putString("soundVelocity", this.mSpeed);
        editor.commit();
    }

    protected void setVolume(String volume) {
        this.mVolume = volume;
        SharedPreferences.Editor editor = this.mSharedPreferences.edit();
        editor.putString("soundVolume", this.mVolume);
        editor.commit();
    }

    public void onEvent(AIUIEvent event) {
        switch (event.arg1) {
            case 1:
                Log.d("TTS", "开始播放");
                this.isSpeak.set(true);
                break;
            case 2:
                Log.d("TTS", "暂停播放");
                break;
            case 3:
                Log.d("TTS", "恢复播放");
                break;
            case 4:
                Log.d("TTS", " 播放进度为" + event.data.getInt("percent"));
                break;
            case 5:
                Log.d("TTS", "播放完成");
                this.isSpeak.set(false);
                if (null != this.mOnSpeakCallback) {
                    this.mOnSpeakCallback.onSpeak(this.mText);
                }
        }

    }

    protected void speak(String text, String speaker, OnSpeakCallback callback) {
        this.mOnSpeakCallback = callback;
        this.speakImpl(text, speaker);
    }

    private void speakImpl(String text, String speaker) {
        if (TextUtils.isEmpty(text)) {
            Log.e("TTS", "speak text is null");
        } else if (this.mAIUIAgent == null) {
            this.errorSpeak("aiui agent has not create");
        } else {
            this.mText = text;
            byte[] ttsData = new byte[0];

            try {
                ttsData = text.getBytes("utf-8");
            } catch (UnsupportedEncodingException var5) {
                Log.e("TTS", "speakImpl UnsupportedEncodingException");
            }

            AIUIMessage startTts = new AIUIMessage(27, 1, 0, this.speakParamsInit(speaker), ttsData);
            this.mAIUIAgent.sendMessage(startTts);
        }
    }

    private String speakParamsInit(String speaker) {
        StringBuffer params = new StringBuffer();
        if (TextUtils.isEmpty(speaker)) {
            params.append("vcn=").append(this.mVoicer);
        } else {
            params.append("vcn=").append(speaker);
        }

        params.append(",speed=").append(this.mSpeed);
        params.append(",pitch=").append(this.mTone);
        params.append(",volume=").append(this.mVolume);
        params.append(",ent=xtts");
        params.append(",aue=speex-wb;7");
        return params.toString();
    }

    protected void stopSpeaking() {
        this.sendAiuiSpeakState(4);
        if (null != this.mOnSpeakCallback) {
            this.mOnSpeakCallback = null;
        }

    }

    protected void pauseSpeaking() {
        this.sendAiuiSpeakState(2);
    }

    protected void resumeSpeaking() {
        this.sendAiuiSpeakState(3);
    }

    private void sendAiuiSpeakState(int state) {
        if (null != this.mAIUIAgent) {
            AIUIMessage startTts = new AIUIMessage(27, state, 0, "", (byte[])null);
            this.mAIUIAgent.sendMessage(startTts);
        } else {
            this.errorSpeak("aiui agent has not create");
        }

    }

    private void errorSpeak(String msg) {
        if (null != this.mOnSpeakErrorListener) {
            this.mOnSpeakErrorListener.onSpeakError(msg);
        }

    }

    public interface OnSpeakErrorListener {
        void onSpeakError(String var1);
    }

    public interface OnSpeakCallback {
        void onSpeak(String var1);
    }
}
