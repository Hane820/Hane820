package com.starway.starrobot.aiuiability;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import com.iflytek.aiui.AIUIEvent;
import com.jaevc.airobotchat.util.ExceptionUtil;

import org.json.JSONObject;

/**
 *
 */
public class AIUIAbility implements AIUIAdapter.ParseListener {
    private static final String TAG = "AIUIAbility";



    private String mAiuiSubType_nlp = "nlp";
    private String mAiuiSubType_tts = "tts";

    private UserParamsCallback callback;
    // NLP 监听器
    private NLPListener mNLPListeners;
    private StarAiuiAdapter mAdapter;
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private static AIUIAbility sInstance = null;
    private boolean mIsStarted = false;

    public void setAiuiSubType(String type) {
        this.mAiuiSubType_nlp = type;
    }

    public void setUserParamsCallback(UserParamsCallback paramsCallback) {
        this.callback = paramsCallback;
    }

    public static AIUIAbility getInstance() {
        if (null == sInstance) {
            sInstance = new AIUIAbility();
        }

        return sInstance;
    }

    private AIUIAbility() {
    }

    public void initAIUIAbility(Context context) {
        try {
            this.mAdapter = new StarAiuiAdapter(context);
            this.mAdapter.setUserParamsCallback(new StarAiuiAdapter.UserParamsSetCallback() {
                public String getUserParams(Boolean isSendText) {
                    return null != AIUIAbility.this.callback ? AIUIAbility.this.callback.getUserParams(isSendText) : "";
                }
            });
            this.mAdapter.init(this);
            Log.e("testTag","mAdapter 初始化完成！");

        } catch (Exception var3) {
            Log.e("AIUIAbility", "AIUI adapter create failure");
        }

    }

    public void addNLPListener(NLPListener listener) {
        this.mNLPListeners = listener;
    }

    public void initPcmRecoderParams(int audioSource, int sampleRateInHz, int channelConfig, int audioFormat, int minBufferSize) {
        if (this.mAdapter != null) {
            this.mAdapter.initAudio(audioSource, sampleRateInHz, channelConfig, audioFormat, minBufferSize);
        }

    }

    public void sleep() {
        if (this.mAdapter != null) {
            this.mAdapter.stop();
        }

    }

    /** @deprecated */
    @Deprecated
    public void setSleepEnable(boolean isEnable) {
        if (this.mAdapter != null) {
            this.mAdapter.setSleepEnable(isEnable);
        }

    }

    public void resetSleep() {
        if (this.mAdapter != null) {
            this.mAdapter.resetSleep();
        }

    }

    public void start() {
        if (!this.mIsStarted && null != this.mAdapter) {
            this.mAdapter.start();
            this.mIsStarted = true;
        }

    }

    public StarAiuiAdapter getAIUIAdapter() {
        return this.mAdapter;
    }

    public void stop() {
        if (this.mIsStarted && null != this.mAdapter) {
            this.mAdapter.stop();
            this.mIsStarted = false;
        }

    }

    public void onAiuiResponse(AIUIEvent event) {


        try {
            if (event.info == null) {
                return;
            }

            Log.e(TAG,"eventInfo = "+event.info);
            JSONObject bizParamJson = new JSONObject(event.info);
            JSONObject data = bizParamJson.getJSONArray("data").getJSONObject(0);
            JSONObject params = data.getJSONObject("params");
            JSONObject content = data.getJSONArray("content").getJSONObject(0);
            String sub = params.optString("sub");
            Log.e(TAG,"sub = "+sub+" ,mAiuiSubType_nlp = "+mAiuiSubType_nlp);
            if (content.has("cnt_id")) {
                String cnt_id = content.getString("cnt_id");

               // String cntstr = new String(event.data.getByteArray(cnt_id), "utf-8");
                if (TextUtils.equals(this.mAiuiSubType_nlp, sub)) {
                    String cntstr = new String(event.data.getByteArray(cnt_id), "utf-8");
                    Log.e("testTag"," cnt_id = "+cnt_id+", cntstr = "+cntstr+", event.data = "+event.data);
                    final JSONObject cntJson = new JSONObject(cntstr);

                    Log.e("testTag","传过去的cntJson="+cntJson.toString());
                    this.mHandler.post(new Runnable() {
                        public void run() {
                            if (AIUIAbility.this.mNLPListeners != null) {
                                Log.e(TAG,"开始调用我的onAiuiResponse函数！ ");
                                AIUIAbility.this.mNLPListeners.onAiuiResponse(cntJson.toString());
                                Log.e(TAG,"调用我的onAiuiResponse函数成功！ ");
                            }

                        }
                    });
                }else if(TextUtils.equals(this.mAiuiSubType_tts, sub)){

                }
            }
        } catch (Exception var9) {
            ExceptionUtil.printStackTrace("testTag",var9);
            Log.e("AIUIAbility", "onAiuiResponse parse exception");
        }

    }

    public void onAiuiWakeUp() {
        if (this.mNLPListeners != null) {
            this.mNLPListeners.onAiuiWakeUp();
        }

    }

    public void onAiuiSleep() {
        if (this.mNLPListeners != null) {
            this.mNLPListeners.onAiuiSleep();
        }

    }

    public void onAiuiEvent(AIUIEvent event) {
        if (this.mNLPListeners != null) {
            this.mNLPListeners.onAiuiEvent(event);
        }

    }

    public void onError(final int code) {
        if (this.mAdapter != null) {
            this.mAdapter.reset();
        }

        this.mHandler.post(new Runnable() {
            public void run() {
                if (AIUIAbility.this.mNLPListeners != null) {
                    AIUIAbility.this.mNLPListeners.onError(code);
                }

            }
        });
    }

    public void sendText(String text) {
        if (this.mAdapter != null) {
            this.mAdapter.sendText(text);
        }

    }

    public void clearDialogHistory() {
        if (this.mAdapter != null) {
            this.mAdapter.clearDialogHistory();
        }

    }

    public void release() {
        this.mAdapter.releaseRecord();
        this.mAdapter = null;
        this.mNLPListeners = null;
    }

    public interface UserParamsCallback {
        String getUserParams(boolean var1);
    }

    public interface AiuiSubType {
        String NLP = "nlp";
        String TPP = "tpp";
    }
}
