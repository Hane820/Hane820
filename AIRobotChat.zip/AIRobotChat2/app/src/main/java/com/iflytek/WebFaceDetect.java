package com.iflytek;


import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.iflytek.util.FileUtil;
import com.iflytek.util.HttpUtil;
import com.jaevc.airobotchat.util.ExceptionUtil;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import org.apache.commons.codec.binary.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;


/**
 * 人脸检测及属性分析 WebAPI 接口调用示例
 * 运行前：请先填写Appid、APIKey、APISecret以及图片路径
 * 运行方法：直接运行 main() 即可
 * 结果： 控制台输出结果信息
 * 接口文档（必看）：https://www.xfyun.cn/doc/face/xf-face-detect/API.html
 * @author iflytek
 */

public class WebFaceDetect {

        public final static  String requestUrl =  "https://api.xf-yun.com/v1/private/s67c9c78c";
        public final static  String appid ="26fac562"; //请填写控制台获取的APPID,
        public final static  String apiSecret="NzQyN2U0YTM3NmMyZTE0MWYzNGYwNDY1";  //请填写控制台获取的APISecret;
        public final static  String apiKey = "e9d481022ef2eb016e012b0d6300c1e1";  //请填写控制台获取的APIKey
        public final static  String imagePath1="xxxxxxxxxxxx";  //请填写要检测的图片路径
        public final static  String serviceId= "s67c9c78c";


    public static void main(String[] args) throws Exception {
        WebFaceDetect demo = new WebFaceDetect();
        ResponseData respData = demo.faceContrast(imagePath1);
        System.out.println("imagePath11"+imagePath1);
        if (respData!=null && respData.getPayLoad().getFace_detect_result() != null) {
            String textBase64 = respData.getPayLoad().getFace_detect_result().getText();
            String text = new String(Base64.decodeBase64(textBase64));
            System.out.println("人脸检测及属性分析结果(text)base64解码后：");
            System.out.println(text);

        }
    }


    public String getXParam(String imageBase641, String imageEncoding1) {
        JsonObject jso = new JsonObject();

        System.out.println("gexParm的imageBase641"+imageBase641);
        System.out.println("gexParm的imageEncoding1"+imageEncoding1);
        /** header **/
        JsonObject header = new JsonObject();
        header.addProperty("app_id", appid);
        header.addProperty("status", 3);

        jso.add("header", header);

        /** parameter **/
        JsonObject parameter = new JsonObject();
        JsonObject service = new JsonObject();
        service.addProperty("service_kind", "face_detect");
        //service.addProperty("detect_points", "1");//检测特征点
        //service.addProperty("detect_property", "1");//检测人脸属性

        JsonObject faceCompareResult = new JsonObject();
        faceCompareResult.addProperty("encoding", "utf8");
        faceCompareResult.addProperty("format", "json");
        faceCompareResult.addProperty("compress", "raw");
        service.add("face_detect_result", faceCompareResult);
        parameter.add(serviceId, service);
        jso.add("parameter", parameter);

        /** payload **/
        JsonObject payload = new JsonObject();
        JsonObject inputImage1 = new JsonObject();
        inputImage1.addProperty("encoding", imageEncoding1);
        inputImage1.addProperty("image", imageBase641);
        payload.add("input1", inputImage1);

        jso.add("payload", payload);
        System.out.println(jso.toString());
        return jso.toString();
    }


    //读取image
    private byte[] readImage(String imagePath) throws IOException {
        InputStream is = new FileInputStream(imagePath);
        byte[] imageByteArray1 = FileUtil.read(imagePath);
        //return is.readAllBytes();
        return imageByteArray1;
    }

    public ResponseData faceContrast(String imageFirstUrl) throws Exception {

        String url = assembleRequestUrl(requestUrl, apiKey, apiSecret);
        System.out.println("url:"+url);
        System.out.println("imageFirstUrl:"+imageFirstUrl);
        String imageBase641 = new String(Base64.encodeBase64(readImage(imageFirstUrl)), "UTF-8");

        System.out.println("imageBase641:"+imageBase641);
        String imageEncoding1 = imageFirstUrl.substring(imageFirstUrl.lastIndexOf(".") + 1);
        System.out.println("imageEncoding1:"+imageEncoding1);

        //System.out.println("url:"+url);
        return handleFaceContrastRes(url, getXParam(imageBase641, imageEncoding1));
    }

    public static final Gson json = new Gson();

    private ResponseData handleFaceContrastRes(String url, String bodyParam) {
        System.out.println("url11111111:"+url);

        Map<String,String> headers = new HashMap<>();
        headers.put("Content-type", "application/json");

        String result = HttpUtil.doPost2(url, headers,bodyParam);

        if (result != null) {
            System.out.println("人脸检测及属性分析接口调用结果：" + result);
            ResponseData rd =null;
            try{
                rd = json.fromJson(result, ResponseData.class);
            }catch (Exception e){
                ExceptionUtil.printStackTrace("testTag",e);
            }

            return rd;
        } else {
            return null;
        }
    }


    //构建url
    public static String assembleRequestUrl(String requestUrl, String apiKey, String apiSecret) {
        URL url = null;
        // 替换调schema前缀 ，原因是URL库不支持解析包含ws,wss schema的url
        String  httpRequestUrl = requestUrl.replace("ws://", "http://").replace("wss://","https://" );
        try {
            url = new URL(httpRequestUrl);
            //获取当前日期并格式化
            SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("GMT"));
            String date = format.format(new Date());

            String host = url.getHost();
            if (url.getPort()!=80 && url.getPort() !=443){
                host = host +":"+String.valueOf(url.getPort());
            }
            StringBuilder builder = new StringBuilder("host: ").append(host).append("\n").//
                    append("date: ").append(date).append("\n").//
                    append("POST ").append(url.getPath()).append(" HTTP/1.1");
            Charset charset = Charset.forName("UTF-8");
            Mac mac = Mac.getInstance("hmacsha256");
            SecretKeySpec spec = new SecretKeySpec(apiSecret.getBytes(charset), "hmacsha256");
            mac.init(spec);
            byte[] hexDigits = mac.doFinal(builder.toString().getBytes(charset));
            String sha = new String(Base64.encodeBase64(hexDigits),"UTF-8");

            String authorization = String.format("api_key=\"%s\", algorithm=\"%s\", headers=\"%s\", signature=\"%s\"", apiKey, "hmac-sha256", "host date request-line", sha);
            String authBase = new String(Base64.encodeBase64(authorization.getBytes(charset)),"UTF-8");
            return String.format("%s?authorization=%s&host=%s&date=%s", requestUrl, URLEncoder.encode(authBase), URLEncoder.encode(host), URLEncoder.encode(date));

        } catch (Exception e) {
            throw new RuntimeException("assemble requestUrl error:"+e.getMessage());
        }
    }

    public static class ResponseData {
        private Header header;
        private PayLoad payload;
        public Header getHeader() {
            return header;
        }
        public PayLoad getPayLoad() {
            return payload;
        }
    }
    public static class Header {
        private int code;
        private String message;
        private String sid;
        public int getCode() {
            return code;
        }
        public String getMessage() {
            return message;
        }
        public String getSid() {
            return sid;
        }
    }
    public static class PayLoad {
        private FaceResult face_detect_result;
        public FaceResult getFace_detect_result() {
            return face_detect_result;
        }
    }
    public static class FaceResult {
        private String compress;
        private String encoding;
        private String format;
        private String text;
        private int face_num;

        public String getCompress() {
            return compress;
        }
        public String getEncoding() {
            return encoding;
        }
        public String getFormat() {
            return format;
        }
        public String getText() {
            return text;
        }
        public int getFace_num() {
            return face_num;
        }
        public void setFace_num(int face_num) {
            this.face_num = face_num;
        }
    }
}
