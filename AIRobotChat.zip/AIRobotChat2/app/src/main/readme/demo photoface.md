public static final String WEBAPI_APPID = "eef31fe4";
public static final String WEBAPI_API_KEY = "5748e08ae866899068c3b1aad7899181";

    // webapi 接口地址
    public static final String WEBWFV_URL = "https://api.xfyun.cn/v1/service/v1/image_identify/face_verification";

    private void init() {
        //日志初始化
        StarLogAbility.getInstance().initAbility(this);
        //基础能力初始化
        StarCommonAbility.getInstance().initAbility(this,
                RobotType.TYPE_TEACHING, new StarCommonAbility.onResultCallback() {
                    @Override
                    public void onResult(boolean isSuccess, String hardCode) {
                        if (isSuccess) {
                            //硬件和业务状态初始化
                            switch (hardCode) {
                                case PartCode.HARDWARE_PARTCODE.CODE_EMOJI:
                                    //设置初始表情
                                    EmojiHelper.doEmojiBase();
                                    break;
                                case PartCode.HARDWARE_PARTCODE.CODE_GPIO:
                                    //默认加载的时候，将拾音方向设置为默认正前方的0度。
                                    GPIOHelper.getInstance().setMainMic(0);
                                    break;
                                case PartCode.HARDWARE_PARTCODE.CODE_CENTER_LIGHT:
                                    //关闭腹部灯带
                                    CenterLightHelper.takeCenterLightOff();
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                });
    }

}
-----------------------------------------

package com.starway.starrobot;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.hardware.idscanner.IDCardInfo;
import com.starway.starrobot.commonability.HardwareServer;
import com.starway.starrobot.commonability.hardware.base.BaseHardware;
import com.starway.starrobot.face.FaceAlignmentHelper;
import com.starway.starrobot.face.FileUtil;

import static com.starway.starrobot.MyApp.WEBAPI_API_KEY;
import static com.starway.starrobot.MyApp.WEBAPI_APPID;
import static com.starway.starrobot.MyApp.WEBWFV_URL;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
private static final String TAG = MainActivity.class.getSimpleName();

    private HandlerThread handlerThread;
    private Handler mHandler;

    // 拍照得到的照片文件
    private Bitmap mImage = null;

    //身份证阅读器获取的图片
    private Bitmap headImg;

    private TextView name, idcardNumber, birthday;
    private ImageView idCardImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handlerThread = new HandlerThread("faceThead");
        handlerThread.start();
        mHandler = new Handler(handlerThread.getLooper());
        initView();
    }

    /**
     * 初始化控件
     */
    private void initView() {
        name = findViewById(R.id.name);
        idcardNumber = findViewById(R.id.id_card_number);
        birthday = findViewById(R.id.birthday);
        idCardImage = findViewById(R.id.head_img);

        //界面按钮点击处理
        findViewById(R.id.online_register).setOnClickListener(this);
        findViewById(R.id.take_pic).setOnClickListener(this);
        findViewById(R.id.online_verify).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.online_register: //刷身份证获取信息显示
                initIdScannerListener();
                break;
            case R.id.online_verify://webApi进行两张照片的1:1相似度比对
                //用拍照的图片和身份证阅读器获取的图片进行比对
                faceAligement(mImage, headImg);
                //    faceAligement(mImage, mImage);
                break;

            case R.id.take_pic: //拍摄照片
                Intent mIntent = new Intent(MainActivity.this, CameraActivity.class);
                startActivityForResult(mIntent, 1000);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }
        String fileSrc = null;
        if (requestCode == 1000) {
            fileSrc = data.getStringExtra("bitmap");
            if (null != fileSrc) {
                mImage = BitmapFactory.decodeFile(fileSrc);
                ((ImageView) findViewById(R.id.online_img)).setImageBitmap(mImage);
            }
        }

    }

    /**
     * 监听身份证扫描仪
     */
    private void initIdScannerListener() {
        HardwareServer.getInstance().startIdScanWithListener(new BaseHardware.idScanCallback() {
            @Override
            public void onIDscanEnd(final IDCardInfo idCardInfo, final byte[] bytes) {
                Log.d(TAG, "result = " + idCardInfo.getName() + " " + idCardInfo.getIdcardno());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        name.setText("姓名： " + idCardInfo.getName());
                        idcardNumber.setText("身份证号： **************");
                        birthday.setText("出生日期： ******************");
                        headImg = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        idCardImage.setImageBitmap(headImg);
                        HardwareServer.getInstance().stopIdScanner();
                    }
                });
            }

            @Override
            public void onIDscanFailed(int i, String s) {
                Log.e("idscan error", s);
            }
        });
    }

    /**
     * 人脸比对webApi 1:1比对
     */
    private void faceAligement(final Bitmap firstBitmap, final Bitmap secordBitmap) {
        if (null == firstBitmap || null == secordBitmap) {
            showToast("图片数据不能为空");
            return;
        }
        FaceAlignmentHelper.getInstance().init(WEBAPI_APPID, WEBAPI_API_KEY);
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                boolean result = FaceAlignmentHelper.getInstance().faceAlignment(WEBWFV_URL,
                        FileUtil.Bitmap2Bytes(firstBitmap), FileUtil.Bitmap2Bytes(secordBitmap));
                if (result) {
                    showToast("人脸比对通过");
                } else {
                    showToast("人脸比对不通过");
                }
            }
        });
    }


    /**
     * 显示toast提升信息
     *
     * @param value
     */
    private void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }

}
-------------------
package com.starway.starrobot;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.starway.starrobot.commonability.camera.CameraHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
* 相机拍照工具，会调用相机拍照，并将拍照结果保存在/sdcard/Download/LoveRobot/，同时会将拍照的bitmap返回给前面的界面
  */
  public class CameraActivity extends AppCompatActivity implements CameraHelper.GetBitmapListener, CameraHelper.OnCameraPrepareListener {

  /**
    * 摄像头帮助类
      */
      private CameraHelper mCameraHelper;

  /**
    * 是否正在拍照中
      */
      private boolean mPictureTakeStatus = false;

  /**
    * SurfaceView
      */
      private FrameLayout mSurfaceView;

  /**
    * 照片展示
      */
      private ImageView mPicView;

  /**
    * 返回按钮
      */
      private Button mBackBtn;

  /**
    * 拍照按钮
      */
      private Button mShutterBtn;

  /**
    * 裁剪按钮
      */
      private Button mCropBtn;

  /**
    * 拍照图片
      */
      private Bitmap mBitmap;

  private CameraManager mCameraManager;
  private String[] mCameraIdList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        mCameraHelper = new CameraHelper(this);
        initData();
        initView();
    }

    private void initData() {
        mCameraHelper = new CameraHelper(this);
        mCameraManager = (CameraManager) getApplicationContext().getSystemService(Context.CAMERA_SERVICE);
        try {
            mCameraIdList = mCameraManager.getCameraIdList();
        } catch (CameraAccessException e) {
            throw new RuntimeException(e);
        }
    }

    protected void initView() {
        mPicView = (ImageView) findViewById(R.id.iv_pic);
        mSurfaceView = (FrameLayout) findViewById(R.id.surface_frame);
        mBackBtn = (Button) findViewById(R.id.btn_back);
        mCropBtn = (Button) findViewById(R.id.btn_crop);
        mShutterBtn = (Button) findViewById(R.id.btn_shutter);
        //初始化摄像头
        initCamera();

    }


    /**
     * 处理摄像头初始化等操作
     */
    private void initCamera() {
        try {
            mCameraHelper.setGetBitmapListener(this);
            mCameraHelper.setOnCameraPrepareListener(this);
            if (mCameraIdList == null || mCameraIdList.length == 0) {
                showToast("未检测到相机");
                finish();
            } else {
                for (String s : mCameraIdList) {
                    Log.d("CameraActivity", "mCameraIdList: " + s);
                }
                /**
                 * 开发平台和机器人本体会有差异:
                 * 在机器人本体上相机ID为固定ID（CameraHelper.CameraID.CAMERA_FRONT、CameraHelper.CameraID.CAMERA_BACK）;
                 * 在开发平台相机ID不固定，所以需要提前获取相机ID
                 */
                mCameraHelper.openCamera(mSurfaceView, Integer.parseInt(mCameraIdList[0]));
                //     mCameraHelper.openCamera(mSurfaceView, CameraHelper.CameraID.CAMERA_BACK);
            }
        } catch (Exception ex) {
            showToast("初始化摄像头出现异常：" + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * 获取图片
     */
    @Override
    public void getBitmap(final Bitmap bitmap) {
        mBitmap = bitmap;
        mPicView.setImageBitmap(bitmap);
        mPicView.setVisibility(View.VISIBLE);
        mCropBtn.setVisibility(View.VISIBLE);
        mBackBtn.setVisibility(View.VISIBLE);
        mShutterBtn.setVisibility(View.INVISIBLE);
        mPictureTakeStatus = false;

    }

    /**
     * 拍照点击事件
     **/
    public void shutterClick(View view) {
        if (mPictureTakeStatus) {
            return;
        }
        mPictureTakeStatus = true;
        mCameraHelper.takePreView();
    }

    public void cropBtnClick(View view) {
        Intent intent = new Intent();
        intent.putExtra("bitmap", saveBitmap());
        setResult(RESULT_OK, intent);
        mCameraHelper.closeCamera();
        CameraActivity.this.finish();

    }

    /**
     * 保存方法
     */
    public String saveBitmap() {
        File f = new File("/sdcard/Download/LoveRobot/", System.currentTimeMillis() + ".jpg");
        f.mkdirs();
        if (f.exists()) {
            f.delete();
        }

        try {
            f.createNewFile();
            FileOutputStream out = new FileOutputStream(f);
            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(CameraActivity.this, "保存成功,文件路径:Download/LoveRobot/", Toast.LENGTH_LONG).show();
                }
            });
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return f.getAbsolutePath();
    }

    /**
     * 返回
     *
     * @param view
     */
    public void backBtnClick(View view) {
        mPicView.setVisibility(View.GONE);
        mBackBtn.setVisibility(View.GONE);
        mCropBtn.setVisibility(View.GONE);
        mShutterBtn.setVisibility(View.VISIBLE);
    }


    /**
     * 初始化监听
     */
    @Override
    public void prepare() {
        mShutterBtn.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCameraHelper.closeCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }








    private void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }
}

