  //    // AIUIAbility.getInstance().initAIUIAbility(this);机子调试
//        private Handler mHandler;
//
//        //设置AIUI监听
//        AIUIAbility.getInstance().addNLPListener(this);
//        SpeechHelper.getInstance().initSpeech(this);
//        //AIUIAbility.getInstance().setAiuiSubType();
//        SpeechHelper.getInstance().setVoicer("xiaofeng");
//        mHandler = new Handler(getMainLooper());
//        startWakeUpAction();
/**************************************************************/


---


//@Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.facewake);
//
//        // 设置屏幕为横屏
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//
//        SurfaceView surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
//
//        //surfaceview裁剪成圆形
//        Object dp1 = 5;
//        surfaceView.setOutlineProvider(new CircleViewOutlineProvider(dp1));
//        surfaceView.setClipToOutline(true);
//
//
//        //俞宙 人脸识别相关
//
//        //返回上一页按钮
//        Button btn2 = (Button) findViewById(R.id.facewakebuttonback);
//
//        //返回上一按钮跳转
//        btn2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent();
//                intent.setClass(facewakejava.this, homepagejava.class);
//                startActivity(intent);
//            }
//        });
//
//        //暂时禁用 StrictMode 如果不禁用的话网络端口服务会报错！
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//        StrictMode.setThreadPolicy(policy);
//
//
//        //调用摄像头
//        setContentView(R.layout.facewake);
//        mHolder = ((SurfaceView) findViewById(R.id.surfaceView)).getHolder();
//        mHolder.addCallback(this);
//        mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
//        mAutoFocusSupported = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_AUTOFOCUS);
//        mAutoTakePicture =true;
//        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this,
//                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
//                    REQUEST_CAMERA_PERMISSION);//1
//        }
//        // 尝试打开前置摄像头
//        mCamera = getCameraInstance(CAMERA_FRONT);
//    }
//
//
//    /**************************getCameraInstance**************************************/
//
//    private Camera getCameraInstance(int cameraId) {
//        Camera c = null;
//        try {
//            c = Camera.open(cameraId);
//        } catch (Exception e) {
//            // 无法打开指定摄像头时，尝试打开后置摄像头（这里假设后置摄像头ID为0，实际可能因设备而异）
//            if (cameraId == CAMERA_FRONT) {
//                try {
//                    c = Camera.open(CAMERA_BACK);//0
//                } catch (Exception e2) {
//                    Log.e(TAG, "无法打开后置摄像头: " + e2.getMessage());
//                }
//            } else {
//                Log.e(TAG, "无法打开前置摄像头: " + e.getMessage());
//            }
//        }
//        return c;
//    }
//
//    /******************************俞宙人脸识别**********************************/
//    public void surfaceCreated(SurfaceHolder holder) {
//        try {
//            mCamera = Camera.open();
//            mCamera.setPreviewDisplay(holder);
//        } catch (IOException e) {
//            Log.e(TAG, "Error setting camera preview: " + e.getMessage());
//        }
//    }
//
//
//    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
//        if (mHolder.getSurface() == null) {
//            return;
//        }
//
//        try {
//            mCamera.stopPreview();
//        } catch (Exception e) {
//            Log.e(TAG, "Error stopping camera preview: " + e.getMessage());
//        }
//
//        try {
//            // 设置相机参数以实现竖屏预览
//            Camera.Parameters parameters = mCamera.getParameters();
////            parameters.set("orientation", "portrait");
//            if (parameters.getSupportedPreviewFormats()!= null) {
//                int orientation = 90; // 旋转90度，将横屏转为竖屏
//                mCamera.setDisplayOrientation(orientation);
//                parameters.setRotation(orientation);
//            }
//            mCamera.setParameters(parameters);
//            mCamera.setPreviewDisplay(mHolder);
//            mCamera.startPreview();
////            mCamera.setPreviewDisplay(mHolder);
////            mCamera.startPreview();
//            if (mAutoFocusSupported) {
//                mCamera.autoFocus(null);
//            }
//            if (mAutoTakePicture) {
//                mCamera.takePicture(null, null, mPicture);
//            }
//        } catch (Exception e) {
//            Log.e(TAG, "Error starting camera preview: " + e.getMessage());
//        }
//    }
//
//
//    public void surfaceDestroyed(SurfaceHolder holder) {
//        // 释放相机资源
//        mCamera.stopPreview();
//        mCamera.release();
//        mCamera = null;
//    }
//
//    public void startAutoTakePicture() {
//        mAutoTakePicture = true;
//    }
//
//    public void stopAutoTakePicture() {
//        mAutoTakePicture = false;
//    }
//
//    private Camera.PictureCallback mPicture = new Camera.PictureCallback() {
//        @Override
//        public void onPictureTaken(byte[] data, Camera camera) {
//            // 这里可以处理拍照后的数据
//            // Bundle extras = data.getExtras();
//            Bitmap imageBitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
////            Bitmap imageBitmap = (Bitmap) extras.get("data");
//            File photoFile = null;
//            try {
//                photoFile = createImageFile();
//            } catch (IOException e) {
////                throw new RuntimeException(e);
//            }
//            imagePath1= savePhoto(imageBitmap,photoFile);
//            System.out.println("imagePath11111"+imagePath1);
//
//            String result;
//            try {
//                result = doCompare(imagePath1);
//                if("检测到人脸".equals(result)){
//                    Intent intent1 = new Intent(facewakejava.this, MainActivity.class);
//                    startActivity(intent1);
//                }
//                else {
//                    runOnUiThread(() -> {
//                        AlertDialog.Builder builder = new AlertDialog.Builder(facewakejava.this);
//                        builder.setTitle("人脸检测结果");
//                        builder.setMessage("未检测到人脸，请重新尝试。");
//                        builder.setPositiveButton("确定", (dialog, which) -> {
//                            // 点击确定按钮可在此处添加后续操作，比如重新检测等，这里暂不做具体设置
//                            Intent intent1 = new Intent(facewakejava.this, homepagejava.class);
//                            startActivity(intent1);
//                        });
//                        AlertDialog alertDialog = builder.create();
//                        alertDialog.show();
//                    });
//                }
//
//            } catch (Exception e) {
//                result = "出错了！："+e.getMessage();
//
//            }
//
//        }
//    };
//    public String doCompare(String imagePath1) throws Exception{
//        WebFaceDetect demo = new WebFaceDetect();
//        WebFaceDetect.ResponseData respData = demo.faceContrast(imagePath1);
//        System.out.println("imagePath22222:"+imagePath1);
//        if (respData!=null && respData.getPayLoad().getFace_detect_result() != null) {
//            String textBase64 = respData.getPayLoad().getFace_detect_result().getText();
//            System.out.println("222222textBase64：" + textBase64);
//            String text = null;
//            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
//                text = new String(Base64.getDecoder().decode(textBase64));
//            }
//            // 新增代码开始
//            Gson gson = new Gson();
//            WebFaceDetect.FaceResult faceResult = gson.fromJson(text, WebFaceDetect.FaceResult.class);
//            if (faceResult!= null) {
//                int face_num = faceResult.getFace_num();
//                System.out.println("检测到的人脸数量: " + face_num);
//                if (face_num >0) {
//                    return "检测到人脸";
//                } else {
//                    return "未检测到人脸";
//                }
//            }
//        }
//        return null;
//    }
//    @Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == 1) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                // 权限已授予，可以正常进行拍照保存等操作
//            } else {
//                // 权限被拒绝，可在此处给用户提示，告知无法保存照片等情况
//                Toast.makeText(this, "无法保存照片，因为未授予存储权限", Toast.LENGTH_SHORT).show();
//            }
//
//        }
//    }
//    private File createImageFile() throws IOException {
//        // 创建一个唯一的文件名
//        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//        String imageFileName = "JPEG_" + timeStamp + "_";
//        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
//        File image = File.createTempFile(
//                imageFileName,  /* 文件名前缀 */
//                ".jpg",         /* 后缀 */
//                storageDir      /* 目录 */
//        );
//        return image;
//    }
//
//    private String savePhoto(Bitmap bitmap, File file) {
//
//        try {
//            FileOutputStream fos = new FileOutputStream(file);
//            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
//            fos.close();
//            return file.getAbsolutePath();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//
//    @Override
//    public void onPointerCaptureChanged(boolean hasCapture) {
//        super.onPointerCaptureChanged(hasCapture);
//    }


